<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Vasantha Industries Limited</title>
        <meta name="description" content="Responsive Multi-Purpose HTML Template">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#222222"> <!-- Android 5.0 Tab Color -->
        <link rel="shortcut icon" href="./img/favicon.JPG">

      

        <!-- Icon Fonts CSS -->
        <link rel="stylesheet" href="css/knight-iconfont.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!-- <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css"> -->

        <!-- Vendor CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/reset.css">

        <!-- Plugins CSS -->
        <link rel="stylesheet" href="css/jquery.fs.shifter.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/settings.css">
        <link rel="stylesheet" href="css/animate.css">

        <!-- Template CSS -->
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/shortcodes.css">
        <link rel="stylesheet" href="css/custom-bg.css">
		
        <!-- JS -->
		<link rel="stylesheet" href="css/timeline.css">
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body oncontextmenu="return false;" class="shifter offcanvas-menu-right offcanvas-menu-dark sticky-header">
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

		 
		
        <!-- mobile-header-wrapper -->
        <div class="mobile-header-wrapper style1 shifter-header clearfix hidden-md hidden-lg">
            <div class="shifter-handle style1">
                <a href="#" class="bars">
                    <span></span>
                    <span></span>
                    <span></span>
                </a><!-- /bars -->
            </div><!-- /menu-trigger -->
            <div class="logo-container">
                <a href="index.php" class="logo">
                   
                <a href="index.php"><img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo"></a>
            
                </a>
            </div><!-- /logo-container -->
           
            
        </div>
        <!-- /mobile-header-wrapper -->

        <!-- OFF CANVAS MOBILE MENU -->
        <nav class="main-nav offcanvas-menu mobile-nav shifter-navigation fullwidth-items dark-bg">
            <div class="logo-container">
                                <a href="index.php"><img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo"></a>
            </div><!-- /logo-container -->
			<form action="#" class="search-form">
                
				<input type="search" name="mobile-search-form" id="mobile-search-form" placeholder="Search">
                <input type="submit" value="">
            </form>
        </nav>

        <div class="main-wrapper shifter-page">

            <!-- Start main-header -->
            <header class="main-header style2 overlay-header">
                        <div class="main-header-inner">
                    
                    <div class="main-bar padding-20 white-bg">
                        <div class="container">
                            <div class="logo-container">
                                <a href="index.php" class="logo">
                                    <img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo">
                                </a>
                            </div><!-- /logo-container -->
                            <div class="menu-container clearfix">
                                <nav class="main-nav style1 active-style1" id="main-nav">
                                    <ul class="clearfix">
                                    
                                        <li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">About Us</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-2 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="vision.php">Vision</a></li>
                                                                <li><a href="journey.php">The Journey</a></li>
                                                        
                                                                <li><a href="welfare.php">Welfare</a></li>
                                                            </ul>
                                                        </div>
                                                        
                                                        
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										
										<li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Spinning</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-2 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="spinningquality.php">Quality</a></li>
                                                                <li><a href="spinningprocess.php">Process</a></li>
                                                                <li><a href="spinningmachinery.php">Machinery</a></li>
                                                                <li><a href="spinningproduct.php">Product</a></li>
                                                            </ul>
                                                        </div>
                                                        
                                                        
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										
										<li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Corrugation</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-2 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="corrugationquality.php">Quality</a></li>
                                                                <li><a href="corrugationprocess.php">Process</a></li>
                                                                <li><a href="corrugationmachinery.php">Machinery</a></li>
                                                                <li><a href="corrugationproduct.php">Product</a></li>
                                                            </ul>
                                                        </div>
                                                        
                                                        
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										
                                        
                                           
                                        </li>
                                        
                                       
                                        

										
										 <li>
                                            <a href="gallery.php">Gallery</a>
                                            
                                           
                                        </li>
										
										 <li>
                                            <a href="contact.php">Contact</a>
                                            
                                           
                                        </li>
                                    </ul>
                                </nav>
                            </div><!-- /menu-container -->
                        </div><!-- /container -->
                    </div><!-- /main-bar -->
                </div><!-- /main-header-inner -->
               <img  src="./img/IMG_9736.jpg" height="350"  width="1400" alt="vasantha Industries">
            </header>
            <!-- End main-header -->
		   <section class="main-contents">
                <div class="testimonials-container testimonials-container">
                    <div class="container">
                        <div class="row">
						<h6>Promoter</h6>
						<p>Vasantha Industries is promoted by a highly motivated team of individuals, who with their vast experience and exemplary vision have made it a leading brand.</p>
                            <div class="col-md-10 col-md-offset-1 wow bounceInRight">
                              
                                <div class="testimonials-carousel">
                                   
                                       
                                      <center>    <img class="md" src="img/cap.jpg" style="height: 119px;width: 115px;"></center>
                                       
                                        <div class="client-info">
                                            <p class="client-name">Sri Vasantha Venkata Krishna Prasad</p>
                                            <p class="client-job">Managing Director</p>
                                        </div>
                                        <p>Sri Krishna Prasad, a young and dynamic entrepreneur, is the Promoter and CEO of the Company. His leadership is the strength of the Company in all its business avenues, expansions and explorations. With a vast, rich and multi dimensional experience spanning a decade and half, he promises to lead this Company to great shores of success</p><br>
                                    <p>His dynamic leadership has received accolades all across. His prudent approach with deep insight into all aspects of the business, led the 'Vasantha Group' from a humble inception to a brand of great reputation and good standing in the market. His experience in real estate and construction of premium residential colonies has well woven itself into setting up of highest standards for the Group.</p>
									
                                   
                                
                            </div><!-- /col-md-10 -->
                        </div><!-- /row -->
                    </div><!-- /container -->
                </div><!-- /testimonials-container -->
				</div>
            </section>	
			
			<section class="main-contents padding-bottom">
                <div class="container">
                   
                    </div> 
               
            </section>

           <div class="container bootstrap snippet">
    <section id="news" class="white-bg padding-top-bottom">
    	<div class="container bootstrap snippet">
			<div class="timeline">
				<div class="date-title">
					<span>Jan 2007</span>
				</div>
				<div class="row">
					<div class="col-sm-6 news-item">
						<div class="news-content">
							<div class="date">
								<p>29</p>
								<small>Fri</small>
							</div>
							
							
							<p>Ever since, we are proud yet humble in surpassing the expectations of one and all and achieving the highest quality standards well below the Uster 5% in both Weaving and Knitting with count ranges of 40’s, 50’s and 60’s – Combed and Carded</p>
							
						</div>
					</div>
					
					<div class="col-sm-6 news-item right">
						<div class="news-content">
							
							<h2 class="news-title">April 2009</h2>
							
							<p>The Company’s successful operations have prompted the Management to enhance the capacity by 25% i.e. by 6720 spindles. This addition brought the company’s total spinning strength to 33120 spindles by April 2009. The Management further proposes to enhance the capacity in the next few months with an average count pattern of 35’s.</p>
							
						</div>
					</div>
				</div>
				
				<div class="row">
					<div class="col-sm-6 news-item">
						<div class="news-content">
							
							
							
							<p>The Company’s quality achievement is a result of the fine mixing of Customer Oriented Management Policy, Sophisticated Manufacturing Methods, highly dedicated and self motivated team, well planned and co-ordinated operations and stringent quality checks. Exceeding the customer expectations in all parameters have been a motivating factor in all our operations.</p>
							
						</div>
					</div>
					
					<div class="col-sm-6 news-item right">
						<div class="news-content">
							
							
						
							<p>Our Yarn Conditioning Plant helps extracting better warping and loom shed efficiency. The yarn is packed as per the customer requirement including that of Carton Packing (5 Ply with 150 gsm) and Pallet Packing. Our normal cone weight is 1.89 Kg and paper cone is ‘Conitex with 5.57’ conacity’.</p>
							
						</div>
					</div>
				</div>
				
				<div class="date-title">
					<span>February 2014</span>
				</div>
				<div class="row">	
					<div class="col-sm-6 news-item">
						<div class="news-content">
							
						<!--	<div class="news-media video">
								<a class="colorbox-video cboxElement" href="#">
									<img class="img-responsive" src="http://lorempixel.com/400/400/sports/5/" alt="">
								</a>
							</div> -->
							<p>The Company will continue its strides in the textile industry with backward integration i.e. Ginning and Forward integration i.e. Weaving and Processing along with lateral expansion in spinning up to 1,00,000 spindles.</p>
						
						</div>
					</div>
					
					
				</div>
			</div>
		</div>
	</section>
</div>	

            <!-- End main-section -->

            

          

           

          <!-- Start main-footer -->
           <footer class="main-footer padding-top96 sm-padding-top80 dark-bg">
                <div class="container">
                    <div class="row">
                       <div style="color:white;" class="col-md-4">
                            <div class="widget widget-contact-info widget-contact-info-style2">
                                <h6 class="">Corporate Office</h6>
                                <address>
                                    <p>
									 </strong>Vasantha House, Survey No 79,
Hafeezpet, Serilingampally Mandal,Hyderabad
                                    </p>
                                   
                                    <p>
                                        <strong>Phone Number</strong>
                                        <span>9502776111/9502778111 </span>
                                       
                                    </p>
									
                                </address>
                            </div><!-- /widget-contact-info -->
                        </div><!-- /col-md-3 -->
                   
                        <div  style="color:white;" class="col-md-8">
                            <div class="widget widget-contact-info widget-contact-info-style2">
                               <center> <h6>Regd. Office & Factory</h6>
                                <address>
                                    <p>
									D. No. 4-383/2,  Vasantha Industries Limited
                        NH-16(old NH-5), Thimmapuram Village,<br >
                        Edlapadu Mandal, Guntur District - 522233,Andhra Pradesh
                                       
                                    </p>
                                   
                                    <p>
                                        <strong>Phone Number</strong>
                                        <span> +91 - 8647 - 276668 , 276669</span>
                                       
                                    </p>
									 
                                    <p>
                                        <strong>Email Address</strong>
                                        <a href="mailto:info@vasanthaspinners.com"><u>info@vasanthaspinners.com</u></a>
                                    </p></center>
                                </address>
                            </div><!-- /widget-contact-info -->
                        </div><!-- /col-md-3 -->
                      
					  
                      
					  
					  
                    </div><!-- /row -->
                </div><!-- /container -->
               
            </footer>
            <!-- End main-footer -->
          

        </div><!-- /main-wrapper -->

        <!-- JS -->
        <script src="js/vendor/jquery.min.js"></script>
        <script src="js/jquery.themepunch.tools.min.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/imagesloaded.pkgd.min.js"></script>
        <script src="js/jquery.fs.shifter.min.js"></script>
        <script src="js/jquery.stellar.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/isotope.pkgd.min.js"></script>
        <script src="js/jquery.countTo.js"></script>
        <script src="js/jquery.appear.js"></script>
		<script src="js/bootstrap.min.js"></script>
        
          <script src="js/jpreloader.js"></script>
        <script src="js/tweetie.min.js"></script>
        <script src="js/jquery.nav.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/video.js"></script>
        <script src="js/main.js"></script>
        <script type="text/javascript">
            jQuery(document).ready(function() {
                   jQuery('.tp-banner').revolution(
                    {
                        delay:9000,
                        startwidth:1170,
                        startheight:500,
                        fullScreen: 'on',
                        navigationType: 'bullet',
                        navigationArrows: 'none',
                        navigationStyle: 'knight-1',
                        navigationVOffset: 60,
                        hideTimerBar: 'on'
                    });
            });
        </script>
        
    </body>
</html>
