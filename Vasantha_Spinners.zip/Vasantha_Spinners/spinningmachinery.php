<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Vasantha Industries Limited</title>
        <meta name="description" content="Responsive Multi-Purpose HTML Template">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#222222"> <!-- Android 5.0 Tab Color -->
        <link rel="shortcut icon" href="./img/favicon.JPG">

      

        <!-- Icon Fonts CSS -->
        <link rel="stylesheet" href="css/knight-iconfont.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!-- <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css"> -->

        <!-- Vendor CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/reset.css">

        <!-- Plugins CSS -->
        <link rel="stylesheet" href="css/jquery.fs.shifter.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/settings.css">
        <link rel="stylesheet" href="css/animate.css">

        <!-- Template CSS -->
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/shortcodes.css">
        <link rel="stylesheet" href="css/custom-bg.css">

        <!-- JS -->
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body oncontextmenu="return false;" class="shifter offcanvas-menu-right offcanvas-menu-dark sticky-header">
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

		 
		
        <!-- mobile-header-wrapper -->
        <div class="mobile-header-wrapper style1 shifter-header clearfix hidden-md hidden-lg">
            <div class="shifter-handle style1">
                <a href="#" class="bars">
                    <span></span>
                    <span></span>
                    <span></span>
                </a><!-- /bars -->
            </div><!-- /menu-trigger -->
            <div class="logo-container">
                <a href="index.php" class="logo">
                   
                <a href="index.php"><img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo"></a>
            
                </a>
            </div><!-- /logo-container -->
           
            
        </div>
        <!-- /mobile-header-wrapper -->

        <!-- OFF CANVAS MOBILE MENU -->
        <nav class="main-nav offcanvas-menu mobile-nav shifter-navigation fullwidth-items dark-bg">
            <div class="logo-container">
                                <a href="index.php"><img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo"></a>
            </div><!-- /logo-container -->
			<form action="#" class="search-form">
                
				<input type="search" name="mobile-search-form" id="mobile-search-form" placeholder="Search">
                <input type="submit" value="">
            </form>
        </nav>

        <div class="main-wrapper shifter-page">

            <!-- Start main-header -->
            <header class="main-header style2 overlay-header">
                        <div class="main-header-inner">
                    
                    <div class="main-bar padding-20 white-bg">
                        <div class="container">
                            <div class="logo-container">
                                <a href="index.php" class="logo">
                                    <img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo">
                                </a>
                            </div><!-- /logo-container -->
                            <div class="menu-container clearfix">
                                <nav class="main-nav style1 active-style1" id="main-nav">
                                    <ul class="clearfix">
                                    
                                        <li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">About Us</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-2 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="vision.php">Vision</a></li>
                                                                <li><a href="journey.php">The Journey</a></li>
                                                        
                                                                <li><a href="welfare.php">Welfare</a></li>
                                                            </ul>
                                                        </div>
                                                        
                                                        
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										
										<li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Spinning</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-2 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="spinningquality.php">Quality</a></li>
                                                                <li><a href="spinningprocess.php">Process</a></li>
                                                                <li><a href="spinningmachinery.php">Machinery</a></li>
                                                                <li><a href="spinningproduct.php">Product</a></li>
                                                            </ul>
                                                        </div>
                                                        
                                                        
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										
										<li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Corrugation</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-2 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="corrugationquality.php">Quality</a></li>
                                                                <li><a href="corrugationprocess.php">Process</a></li>
                                                                <li><a href="corrugationmachinery.php">Machinery</a></li>
                                                                <li><a href="corrugationproduct.php">Product</a></li>
                                                            </ul>
                                                        </div>
                                                        
                                                        
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										
                                        
                                           
                                        </li>
                                        
                                       
                                        

										
										 <li>
                                            <a href="gallery.php">Gallery</a>
                                            
                                           
                                        </li>
										
										 <li>
                                            <a href="contact.php">Contact</a>
                                            
                                           
                                        </li>
                                    </ul>
                                </nav>
                            </div><!-- /menu-container -->
                        </div><!-- /container -->
                    </div><!-- /main-bar -->
                </div><!-- /main-header-inner -->
                 <img src="./img/IMG_9446.jpg"  height="350" width="1400" alt="Knight Client">
            </header>
            <!-- End main-header -->
			

           
            <section class="main-contents small-padding smocky-white-bg">
                <div class="container">
                    <div class="tabs-container tab-style2">
                        <ul class="nav nav-tabs">
                            <li class=""><a href="#marketing2" data-toggle="tab">UNIT-1 (31776 Spls.)</a></li>
                            <li class="wow fadeInDown" data-wow-delay="0.2s"><a href="#branding2" data-toggle="tab">UNIT-2 (35040 Spls.)</a></li>
                            
                        </ul>
                        <div class="tab-content wow fadeInLeft" data-wow-delay="1s">
                            <div class="tab-pane active" id="marketing2">
                              <table class="table table-bordered">
                            <tr>
                                <td>
                                    Department
                                </td>
                                <td>
                                    Machine Type
                                </td>
                                <td>
                                    Model
                                </td>
                                <td>
                                    Make
                                </td>
                                <td>
                                    Quantity
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Blow Room
                                </td>
                                <td>
                                    Bale Plucker
                                </td>
                                <td>
                                    LA-23
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Sead Trap
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Aero Tech
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    HCC
                                </td>
                                <td>
                                    LA 3/2
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    HCV
                                </td>
                                <td>
                                    LA 5/3
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Vario Clean
                                </td>
                                <td>
                                    LB 9/1
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Cotton Contamination Cleaning M/c
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Vetal
                                </td>
                                <td>
                                    3 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Unimix
                                </td>
                                <td>
                                    LB 7/4R
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    2 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Flexi Clean
                                </td>
                                <td>
                                    LB 5/6
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    2 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Carding
                                </td>
                                <td>
                                    LC 300A Cards
                                </td>
                                <td>
                                    LC-300A
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    21 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Card Room Accessories
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    LCC
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Drawing
                                </td>
                                <td>
                                    L DO/6s Drawings
                                </td>
                                <td>
                                    L DO/6s
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    4 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    LRSB Digital Drawings
                                </td>
                                <td>
                                    LRSB 851
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    6 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Lap Formers
                                </td>
                                <td>
                                    Super Lap Former
                                </td>
                                <td>
                                    LH-10
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    2 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Combers
                                </td>
                                <td>
                                    LK54 Combers
                                </td>
                                <td>
                                    LK54
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    10 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    LK64 Combers
                                </td>
                                <td>
                                    LK64
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Speed Frames
                                </td>
                                <td>
                                    LFS 1660 Speed Frames (120 Spls.)
                                </td>
                                <td>
                                    LFS 1660
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    7 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Ring Frames
                                </td>
                                <td>
                                    LR 6/s Ring Frames 1200 Spl. Each
                                </td>
                                <td>
                                    LR 6/S
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    22 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    LR 6/s Ring Frames 672 Spl. Each
                                </td>
                                <td>
                                    LR 6/S
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    8Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Cot Room Accessories
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    SABAR
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    OHTC
                                </td>
                                <td>
                                    OHTC
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Unirols
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Autoconer
                                </td>
                                <td>
                                    Schlafhorst AC5 Autoconers With Loepfe 'Zenith FP' EYC
                                </td>
                                <td>
                                    AC5
                                </td>
                                <td>
                                    Schlafhorst
                                </td>
                                <td>
                                    9 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Reeling
                                </td>
                                <td>
                                    Double Side Reels
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    KR Sakti
                                </td>
                                <td>
                                    24 Nos (48 Reels)
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    QAD
                                </td>
                                <td>
                                    Wrap Reel
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Statex
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Wrap Block
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Statex
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Twist Tester
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Statex
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    CSP Tester
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Statex
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Appereance Bord Winder
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Statex
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    High Volume Instrument (HVI)
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    USTER
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Uster Tester (UT - 5)
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    USTER
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Humidification
                                </td>
                                <td>
                                    Batliboi Humidification System with Automatic Controls
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Batliboi
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Waste Collection system
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Batliboi
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Packing
                                </td>
                                <td>
                                    Stretch Wrapping Machine
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    ITW
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    UV Lamp Testing
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    YCP
                                </td>
                                <td>
                                    Yarn Conditioning Plant
                                </td>
                                <td>
                                    Profix 1000
                                </td>
                                <td>
                                    ELGI
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                        </table>  
                            </div><!-- /tab-pane -->
                            <div class="tab-pane fade" id="branding2">
                               <table class="table table-bordered">
                            <tr>
                                <td>
                                    Department
                                </td>
                                <td>
                                    Machine Type
                                </td>
                                <td>
                                    Model
                                </td>
                                <td>
                                    Make
                                </td>
                                <td>
                                    Quantity
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Blow Room
                                </td>
                                <td>
                                    Mixing Bale Opener
                                </td>
                                <td>
                                    LB3/6R
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Vario Clean
                                </td>
                                <td>
                                    LB 9/1
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Cotton Contamination Cleaning M/c
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Vetal
                                </td>
                                <td>
                                    3 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Unimix
                                </td>
                                <td>
                                    LB 7/4R
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    2 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Flexi Clean
                                </td>
                                <td>
                                    LB 5/6
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    2 No
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Carding
                                </td>
                                <td>
                                    LC 333 Cards
                                </td>
                                <td>
                                    LC-333
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    16 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Drawing
                                </td>
                                <td>
                                    L D2 Drawings
                                </td>
                                <td>
                                    L D2
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    4 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    LRSB Digital Drawings
                                </td>
                                <td>
                                    LRSB 851
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    6 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Lap Formers
                                </td>
                                <td>
                                    Super Lap Former
                                </td>
                                <td>
                                    LH-15
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    2 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Combers
                                </td>
                                <td>
                                    LK64 Combers
                                </td>
                                <td>
                                    LK64
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    8 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Speed Frames
                                </td>
                                <td>
                                    LF4200A Speed Frames (160 Spls.)
                                </td>
                                <td>
                                    LF4200A
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    6 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Ring Frames
                                </td>
                                <td>
                                    LR 60A Ring Frames 1200 Spl. Each
                                </td>
                                <td>
                                    LR 60A
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    24 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    LR 6/s Ring Frames 624 Spl. Each
                                </td>
                                <td>
                                    LR 6/S
                                </td>
                                <td>
                                    LMW
                                </td>
                                <td>
                                    10 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    OHTC
                                </td>
                                <td>
                                    OHTC
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Unirols
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Autoconer
                                </td>
                                <td>
                                    Schlafhorst AC5 Autoconers With Loepfe 'Zenith F' EYC
                                </td>
                                <td>
                                    AC5
                                </td>
                                <td>
                                    Schlafhorst
                                </td>
                                <td>
                                    9 Nos
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Humidification
                                </td>
                                <td>
                                    Batliboi Humidification System with Automatic Controls
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Luwa
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Waste Collection system
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                    Luwa
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    YCP
                                </td>
                                <td>
                                    Yarn Conditioning Plant
                                </td>
                                <td>
                                    Profix 1000
                                </td>
                                <td>
                                    ELGI
                                </td>
                                <td>
                                    1 No
                                </td>
                            </tr>
                        </table>
                            </div><!-- /tab-pane -->
                            
                        </div><!-- /tab-content -->
                    </div><!-- /tabs-container -->
                </div><!-- /container -->
            </section>

            

          

           

          <!-- Start main-footer -->
           <footer class="main-footer padding-top96 sm-padding-top80 dark-bg">
                <div class="container">
                    <div class="row">
                       <div style="color:white;" class="col-md-4">
                            <div class="widget widget-contact-info widget-contact-info-style2">
                                <h6 class="">Corporate Office</h6>
                                <address>
                                    <p>
									 </strong>Vasantha House, Survey No 79,
Hafeezpet, Serilingampally Mandal,Hyderabad
                                    </p>
                                   
                                    <p>
                                        <strong>Phone Number</strong>
                                        <span>9502776111/9502778111 </span>
                                       
                                    </p>
									
                                </address>
                            </div><!-- /widget-contact-info -->
                        </div><!-- /col-md-3 -->
                   
                        <div  style="color:white;" class="col-md-8">
                            <div class="widget widget-contact-info widget-contact-info-style2">
                               <center> <h6>Regd. Office & Factory</h6>
                                <address>
                                    <p>
									D. No. 4-383/2,  Vasantha Industries Limited
                        NH-16(old NH-5), Thimmapuram Village,<br >
                        Edlapadu Mandal, Guntur District - 522233,Andhra Pradesh
                                       
                                    </p>
                                   
                                    <p>
                                        <strong>Phone Number</strong>
                                        <span> +91 - 8647 - 276668 , 276669</span>
                                       
                                    </p>
									 
                                    <p>
                                        <strong>Email Address</strong>
                                        <a href="mailto:info@vasanthaspinners.com"><u>info@vasanthaspinners.com</u></a>
                                    </p></center>
                                </address>
                            </div><!-- /widget-contact-info -->
                        </div><!-- /col-md-3 -->
                      
					  
                      
					  
					  
                    </div><!-- /row -->
                </div><!-- /container -->
               
            </footer>
            <!-- End main-footer -->
          

        </div><!-- /main-wrapper -->

        <!-- JS -->
        <script src="js/vendor/jquery.min.js"></script>
        <script src="js/jquery.themepunch.tools.min.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/imagesloaded.pkgd.min.js"></script>
        <script src="js/jquery.fs.shifter.min.js"></script>
        <script src="js/jquery.stellar.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/isotope.pkgd.min.js"></script>
        <script src="js/jquery.countTo.js"></script>
        <script src="js/jquery.appear.js"></script>
		 <script src="js/bootstrap.min.js"></script>
        
        <script src="js/jpreloader.js"></script>
        
        <script src="js/tweetie.min.js"></script>
        <script src="js/jquery.nav.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/video.js"></script>
        <script src="js/main.js"></script>
        <script type="text/javascript">
            jQuery(document).ready(function() {
                   jQuery('.tp-banner').revolution(
                    {
                        delay:9000,
                        startwidth:1170,
                        startheight:500,
                        fullScreen: 'on',
                        navigationType: 'bullet',
                        navigationArrows: 'none',
                        navigationStyle: 'knight-1',
                        navigationVOffset: 60,
                        hideTimerBar: 'on'
                    });
            });
        </script>
        
    </body>
</html>
