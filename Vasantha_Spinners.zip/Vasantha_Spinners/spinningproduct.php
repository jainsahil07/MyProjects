<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Vasantha Industries Limited</title>
        <meta name="description" content="Responsive Multi-Purpose HTML Template">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#222222"> <!-- Android 5.0 Tab Color -->
        <link rel="shortcut icon" href="./img/favicon.JPG">

      

        <!-- Icon Fonts CSS -->
        <link rel="stylesheet" href="css/knight-iconfont.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!-- <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css"> -->

        <!-- Vendor CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/reset.css">

        <!-- Plugins CSS -->
        <link rel="stylesheet" href="css/jquery.fs.shifter.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/settings.css">
        <link rel="stylesheet" href="css/animate.css">

        <!-- Template CSS -->
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/shortcodes.css">
        <link rel="stylesheet" href="css/custom-bg.css">

        <!-- JS -->
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body oncontextmenu="return false;" class="shifter offcanvas-menu-right offcanvas-menu-dark sticky-header">
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

		 
		
        <!-- mobile-header-wrapper -->
        <div class="mobile-header-wrapper style1 shifter-header clearfix hidden-md hidden-lg">
            <div class="shifter-handle style1">
                <a href="#" class="bars">
                    <span></span>
                    <span></span>
                    <span></span>
                </a><!-- /bars -->
            </div><!-- /menu-trigger -->
            <div class="logo-container">
                <a href="index.php" class="logo">
                   
                <a href="index.php"><img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo"></a>
            
                </a>
            </div><!-- /logo-container -->
           
            
        </div>
        <!-- /mobile-header-wrapper -->

        <!-- OFF CANVAS MOBILE MENU -->
        <nav class="main-nav offcanvas-menu mobile-nav shifter-navigation fullwidth-items dark-bg">
            <div class="logo-container">
                                <a href="index.php"><img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo"></a>
            </div><!-- /logo-container -->
			<form action="#" class="search-form">
                
				<input type="search" name="mobile-search-form" id="mobile-search-form" placeholder="Search">
                <input type="submit" value="">
            </form>
        </nav>

        <div class="main-wrapper shifter-page">

            <!-- Start main-header -->
            <header class="main-header style2 overlay-header">
                        <div class="main-header-inner">
                    
                    <div class="main-bar padding-20 white-bg">
                        <div class="container">
                            <div class="logo-container">
                                <a href="index.php" class="logo">
                                    <img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo">
                                </a>
                            </div><!-- /logo-container -->
                            <div class="menu-container clearfix">
                                <nav class="main-nav style1 active-style1" id="main-nav">
                                    <ul class="clearfix">
                                    
                                        <li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">About Us</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-2 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="vision.php">Vision</a></li>
                                                                <li><a href="journey.php">The Journey</a></li>
                                                        
                                                                <li><a href="welfare.php">Welfare</a></li>
                                                            </ul>
                                                        </div>
                                                        
                                                        
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										
										<li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Spinning</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-2 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="spinningquality.php">Quality</a></li>
                                                                <li><a href="spinningprocess.php">Process</a></li>
                                                                <li><a href="spinningmachinery.php">Machinery</a></li>
                                                                <li><a href="spinningproduct.php">Product</a></li>
                                                            </ul>
                                                        </div>
                                                        
                                                        
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										
										<li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Corrugation</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-2 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="corrugationquality.php">Quality</a></li>
                                                                <li><a href="corrugationprocess.php">Process</a></li>
                                                                <li><a href="corrugationmachinery.php">Machinery</a></li>
                                                                <li><a href="corrugationproduct.php">Product</a></li>
                                                            </ul>
                                                        </div>
                                                        
                                                        
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										
                                        
                                           
                                        </li>
                                        
                                       
                                        

										
										 <li>
                                            <a href="gallery.php">Gallery</a>
                                            
                                           
                                        </li>
										
										 <li>
                                            <a href="contact.php">Contact</a>
                                            
                                           
                                        </li>
                                    </ul>
                                </nav>
                            </div><!-- /menu-container -->
                        </div><!-- /container -->
                    </div><!-- /main-bar -->
                </div><!-- /main-header-inner -->
                <div class="tp-wrapper">
                    <div class="tp-banner-container">
                       <img src="./img/IMG_9736.jpg" width="1400" height="350"  alt="vasantha Industries Logo">  
                    </div><!-- /tp-banner-container -->
                </div><!-- /tp-wrapper -->
            </header>
            <!-- End main-header -->
			

 <section class="main-contents small-padding">
                <div class="container">
                   <div class="table-responsive">          
  <table class="table table-bordered">
    <thead>
      
        <tr>
        				<th>Count</th>
                <th>30s Karded Weaving</th>
                <th>30s Karded Knitting</th>
                <th>30s Combed Weaving</th>
                <th>30s Combed Knitting</th>
                <th>32s karded Weaving</th>
				<th>32s karded Knitting</th>
				<th>36s Karded Weaving</th>
				<th>36s Karded Knitting</th>
				<th>36s Combed Weaving</th>
				<th>36s Combed Knitting</th>
				<th>40s karded Weaving</th>
				<th>40s karded Knitting</th>
				<th>40s Combed Weaving</th>
				<th>40s Combed Knitting</th>
				<th>50s Combed Weaving</th>
				<th>50s Combed Knitting</th>
				<th>60s Combed Weaving</th>
				<th>60s Combed Knitting</th>
        			</tr>
      
    </thead>
    <tbody>
       <tr>
                <td>Act.Count(Ne)</td>
                <td>30.25</td>
                <td>30</td>
                <td>30.5</td>
                <td>30</td>
                <td>32.5</td>
				<td>32</td>
				<td>36.5</td>
				<td>36</td>
				<td>36.5</td>
				<td>36</td>
				<td>40.5</td>
				<td>40</td>
				<td>40.5</td>
				<td>40</td>
				<td>50.5</td>
				<td>50</td>
				<td>60.5</td>
				<td>60</td>
            </tr>
			<tr>
                <td>C.S.P</td>
                <td>2700</td>
                <td>2500</td>
                <td>2950+</td>
                <td>2700</td>
                <td>2700</td>
				<td>2500</td>
				<td>2750</td>
				<td>2500</td>
				<td>2950+</td>
				<td>2700</td>
				<td>2700+</td>
				<td>2500</td>
				<td>2900+</td>
				<td>2600+</td>
				<td>2850+</td>
				<td>2600</td>
				<td>2850</td>
				<td>2500+</td>
            </tr>
			<tr>
                <td>Count C.V.%</td>
                <td>1.5</td>
                <td>1.5</td>
                <td>1.5</td>
                <td>1.5</td>
                <td>1.5</td>
				<td>1.5</td>
				<td>1.4</td>
				<td>1.4</td>
				<td>1.5</td>
				<td>1.5</td>
				<td>1.5</td>
				<td>1.5</td>
				<td>1.5</td>
				<td>1.5</td>
				<td>1.5</td>
				<td>1.5</td>
				<td>1.5</td>
				<td>1.5</td>
            </tr>
			<tr>
                <td>Strength C.V.%</td>
                <td>4.5</td>
                <td>4.5</td>
                <td>4</td>
                <td>4</td>
                <td>4.5</td>
				<td>4.5</td>
				<td>4.5</td>
				<td>4.5</td>
				<td>4</td>
				<td>4</td>
				<td>4</td>
				<td>4</td>
				<td>4</td>
				<td>4</td>
				<td>4.5</td>
				<td>4.5</td>
				<td>4.5</td>
				<td>4.5</td>
            </tr>
			<tr>
                <td>T.P.I</td>
                <td>23.56</td>
                <td>20.5</td>
                <td>22.36</td>
                <td>19.7</td>
                <td>23.8</td>
				<td>21.2</td>
				<td>25.8</td>
				<td>22</td>
				<td>24.5</td>
				<td>21.6</td>
				<td>27.9</td>
				<td>23</td>
				<td>26.36</td>
				<td>22.24</td>
				<td>30</td>
				<td>25.5</td>
				<td>32.9</td>
				<td>27.96</td>
            </tr>
			<tr>
                <td>T.M</td>
                <td>4.3</td>
                <td>3.75</td>
                <td>4.08</td>
                <td>3.6</td>
                <td>4.2</td>
				<td>3.75</td>
				<td>4.3</td>
				<td>3.66</td>
				<td>4.08</td>
				<td>3.6</td>
				<td>4.38</td>
				<td>3.64</td>
				<td>4.14</td>
				<td>3.52</td>
				<td>4.22</td>
				<td>3.61</td>
				<td>4.25</td>
				<td>3.61</td>
            </tr>
			<tr>
			<td>UT-5:</td>
			</tr>
			<tr>
                <td>U%</td>
                <td>11.6</td>
                <td>11.4</td>
                <td>9.4</td>
                <td>9.4</td>
                <td>11.7</td>
				<td>11.5</td>
				<td>12</td>
				<td>12</td>
				<td>9.6</td>
				<td>9.4</td>
				<td>12</td>
				<td>12</td>
				<td>9.8</td>
				<td>9.8</td>
				<td>10.4</td>
				<td>10.4</td>
				<td>11</td>
				<td>11</td>
            </tr>
			<tr>
                <td>Thin(-30%)</td>
                <td>1687</td>
                <td>1513</td>
                <td>600</td>
                <td>600</td>
                <td>1700</td>
				<td>1600</td>
				<td>2300</td>
				<td>2300</td>
				<td>820</td>
				<td>600</td>
				<td>2500</td>
				<td>2500</td>
				<td>950</td>
				<td>950</td>
				<td>1500</td>
				<td>1500</td>
				<td>2200</td>
				<td>2200</td>
            </tr>
			<tr>
                <td>Thin(-40%)</td>
                <td>123</td>
                <td>81</td>
                <td>30</td>
                <td>20</td>
                <td>130</td>
				<td>120</td>
				<td>230</td>
				<td>230</td>
				<td>38</td>
				<td>20</td>
				<td>250</td>
				<td>250</td>
				<td>55</td>
				<td>55</td>
				<td>125</td>
				<td>125</td>
				<td>260</td>
				<td>260</td>
            </tr>
			<tr>
                <td>Thin(-50%)/td>
                <td>3</td>
                <td>2</td>
                <td>0</td>
                <td>0</td>
                <td>7</td>
				<td>5</td>
				<td>7</td>
				<td>7</td>
				<td>1</td>
				<td>1</td>
				<td>9</td>
				<td>9</td>
				<td>1</td>
				<td>1</td>
				<td>3</td>
				<td>3</td>
				<td>10</td>
				<td>10</td>
            </tr>
			<tr>
                <td>Thin(+35%)</td>
                <td>826</td>
                <td>788</td>
                <td>210</td>
                <td>150</td>
                <td>850</td>
				<td>800</td>
				<td>950</td>
				<td>950</td>
				<td>210</td>
				<td>150</td>
				<td>1000</td>
				<td>1000</td>
				<td>210</td>
				<td>210</td>
				<td>310</td>
				<td>310</td>
				<td>440</td>
				<td>440</td>
            </tr>
			<tr>
                <td>Thin(+50%)</td>
                <td>154</td>
                <td>130</td>
                <td>15</td>
                <td>13</td>
                <td>160</td>
				<td>150</td>
				<td>193</td>
				<td>193</td>
				<td>20</td>
				<td>14</td>
				<td>194</td>
				<td>194</td>
				<td>24</td>
				<td>24</td>
				<td>27</td>
				<td>27</td>
				<td>40</td>
				<td>40</td>
            </tr>
			<tr>
                <td>Neps(+140%)</td>
                <td>1772</td>
                <td>1780</td>
                <td>270</td>
                <td>260</td>
                <td>1800</td>
				<td>1700</td>
				<td>2300</td>
				<td>2300</td>
				<td>320</td>
				<td>260</td>
				<td>2500</td>
				<td>2500</td>
				<td>330</td>
				<td>330</td>
				<td>550</td>
				<td>550</td>
				<td>800</td>
				<td>800</td>
            </tr>
			<tr>
                <td>Neps(+140%)</td>
                <td>1772</td>
                <td>1780</td>
                <td>270</td>
                <td>260</td>
                <td>1800</td>
				<td>1700</td>
				<td>2300</td>
				<td>2300</td>
				<td>320</td>
				<td>260</td>
				<td>2500</td>
				<td>2500</td>
				<td>330</td>
				<td>330</td>
				<td>550</td>
				<td>550</td>
				<td>800</td>
				<td>800</td>
            </tr>
			<tr>
                <td>Neps(+200%)</td>
                <td>41<9/td>
                <td>368</td>
                <td>45</td>
                <td>43</td>
                <td>450</td>
				<td>400</td>
				<td>550</td>
				<td>550</td>
				<td>54</td>
				<td>52</td>
				<td>597</td>
				<td>597</td>
				<td>55</td>
				<td>55</td>
				<td>70</td>
				<td>70</td>
				<td>90</td>
				<td>90</td>
            </tr>
			<tr>
                <td>Total IPI(-50/+50+200)</td>
                <td>576</td>
                <td>500</td>
                <td>60</td>
                <td>56</td>
                <td>617</td>
				<td>555</td>
				<td>750</td>
				<td>750</td>
				<td>75</td>
				<td>67</td>
				<td>800</td>
				<td>800</td>
				<td>80</td>
				<td>80</td>
				<td>100</td>
				<td>100</td>
				<td>140</td>
				<td>140</td>
            </tr>
			<tr>
                <td>Total IPI all channels</td>
                <td>4984</td>
                <td>4662</td>
                <td>1170</td>
                <td>1086</td>
                <td>5097</td>
				<td>4775</td>
				<td>6530</td>
				<td>6530</td>
				<td>1463</td>
				<td>1097</td>
				<td>7050</td>
				<td>7050</td>
				<td>1625</td>
			    <td>1625</td>
				<td>2585</td>
				<td>2585</td>
				<td>3840</td>
				<td>3840</td>
            </tr>
			<tr>
                <td>Hairiness Index</td>
                <td>6.5</td>
                <td>6.8</td>
                <td>6</td>
                <td>6.2</td>
                <td>6.4</td>
				<td>6.6</td>
				<td>6.2</td>
				<td>6.4</td>
				<td>5.5</td>
				<td>5.8</td>
				<td>6</td>
				<td>6.3</td>
				<td>5.2</td>
				<td>6</td>
				<td>4.9</td>
				<td>5.3</td>
				<td>4.6</td>
				<td>5</td>
            </tr>
			<tr>
                <td>Sh</td>
                <td>1.6</td>
                <td>1.6</td>
                <td>1.28</td>
                <td>1.28</td>
                <td>1.5</td>
				<td>1.5</td>
				<td>1.4</td>
				<td>1.4</td>
				<td>1.28</td>
				<td>1.35</td>
				<td>1.4</td>
				<td>1.3</td>
				<td>1.28</td>
				<td>1.4</td>
				<td>1.28</td>
				<td>1.28</td>
				<td>1.26</td>
				<td>1.28</td>
            </tr>
			<tr>
			<td>UTR-3:</td>
			</tr>
			<tr>
                <td>R.K.M.(g/tex)</td>
                <td>17.5</td>
                <td>15.5</td>
                <td>18.5</td>
                <td>17.5</td>
                <td>17</td>
				<td>15.5</td>
				<td>16.5</td>
				<td>15.5</td>
				<td>18.5</td>
				<td>17.5</td>
				<td>16</td>
				<td>15</td>
				<td>18.5</td>
				<td>17.5</td>
				<td>18+</td>
				<td>16</td>
				<td>18+</td>
				<td>16</td>
            </tr>
			<tr>
                <td>R.K.M.(C.V.%)</td>
                <td>8.5</td>
                <td>9</td>
				<td>8.5</td>
                <td>8.5</td>
                <td>8.5</td>
                <td>9</td>
				<td>9.5</td>
				<td>9.5</td>
				<td>8.5</td>
				<td>8.5</td>
				<td>9</td>
				<td>9</td>
				<td>8.5</td>
				<td>8.5</td>
				<td>8.5</td>
				<td>8.5</td>
				<td>9</td>
				<td>9</td>
            </tr>
			<tr>
                <td>Elongation %</td>
                <td>4.8</td>
                <td>4.6</td>
				<td>4.5</td>
                <td>4.8</td>
                <td>4.6</td>
                <td>4.6</td>
				<td>4.8</td>
				<td>4.8</td>
				<td>4.5</td>
				<td>4.8</td>
				<td>4.3</td>
				<td>4.3</td>
				<td>4.5</td>
				<td>4.8</td>
				<td>4.2</td>
				<td>4.2</td>
				<td>4.5</td>
				<td>4.5</td>
            </tr>
			<tr>
                <td>Elong. C.V.%</td>
                <td>8.5</td>
                <td>9</td>
				<td>8.5</td>
                <td>8.5</td>
                <td>8.5</td>
                <td>9</td>
				<td>9</td>
				<td>9</td>
				<td>8.5</td>
				<td>8.5</td>
				<td>8.5</td>
				<td>8.5</td>
				<td>8.5</td>
				<td>8.5</td>
				<td>8.5</td>
				<td>8.5</td>
				<td>9</td>
				<td>9</td>
            </tr>
			<tr>
			<td>classimat-3</td>
			</tr>
			<tr>
                <td>Total faults</td>
                <td>350</td>
                <td>350</td>
				<td>75</td>
                <td>75</td>
                <td>360</td>
                <td>350</td>
				<td>380</td>
				<td>380</td>
				<td>80</td>
				<td>75</td>
				<td>400</td>
				<td>400</td>
				<td>90</td>
				<td>90</td>
				<td>110</td>
				<td>110</td>
				<td>120</td>
				<td>120</td>
            </tr>
			<tr>
                <td>Obj.faults</td>
                <td>< 1</td>
                <td>< 1</td>
				<td>< 1</td>
                <td>< 1</td>
                <td>< 1</td>
                <td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 2</td>
				<td>< 2</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
            </tr>
			<tr>
                <td>Long thick(E,F,G)</td>
                <td>< 1</td>
                <td>< 1</td>
				<td>< 1</td>
                <td>< 1</td>
                <td>< 1</td>
                <td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 1</td>
            </tr>
			<tr>
                <td>Long thin(H2,I1,I2)</td>
                <td>< 5</td>
                <td>< 5</td>
				<td>< 1</td>
                <td>< 1</td>
                <td>< 5</td>
                <td>< 5</td>
				<td>< 5</td>
				<td>< 5</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 5</td>
				<td>< 5</td>
				<td>< 1</td>
				<td>< 1</td>
				<td>< 5</td>
				<td>< 5</td>
				<td>< 5</td>
				<td>< 5</td>
            </tr>
    </tbody>
  </table> 

                  
					</div>
                </div><!-- /container -->
            </section>
            

          

           

          <!-- Start main-footer -->
           <footer class="main-footer padding-top96 sm-padding-top80 dark-bg">
                <div class="container">
                    <div class="row">
                       <div style="color:white;" class="col-md-4">
                            <div class="widget widget-contact-info widget-contact-info-style2">
                                <h6 class="">Corporate Office</h6>
                                <address>
                                    <p>
									 </strong>Vasantha House, Survey No 79,
Hafeezpet, Serilingampally Mandal,Hyderabad
                                    </p>
                                   
                                    <p>
                                        <strong>Phone Number</strong>
                                        <span>9502776111/9502778111 </span>
                                       
                                    </p>
									
                                </address>
                            </div><!-- /widget-contact-info -->
                        </div><!-- /col-md-3 -->
                   
                        <div  style="color:white;" class="col-md-8">
                            <div class="widget widget-contact-info widget-contact-info-style2">
                               <center> <h6>Regd. Office & Factory</h6>
                                <address>
                                    <p>
									D. No. 4-383/2,  Vasantha Industries Limited
                        NH-16(old NH-5), Thimmapuram Village,<br >
                        Edlapadu Mandal, Guntur District - 522233,Andhra Pradesh
                                       
                                    </p>
                                   
                                    <p>
                                        <strong>Phone Number</strong>
                                        <span> +91 - 8647 - 276668 , 276669</span>
                                       
                                    </p>
									 
                                    <p>
                                        <strong>Email Address</strong>
                                        <a href="mailto:info@vasanthaspinners.com"><u>info@vasanthaspinners.com</u></a>
                                    </p></center>
                                </address>
                            </div><!-- /widget-contact-info -->
                        </div><!-- /col-md-3 -->
                      
					  
                      
					  
					  
                    </div><!-- /row -->
                </div><!-- /container -->
               
            </footer>
            <!-- End main-footer -->
          

        </div><!-- /main-wrapper -->

        <!-- JS -->
        <script src="js/vendor/jquery.min.js"></script>
        <script src="js/jquery.themepunch.tools.min.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/imagesloaded.pkgd.min.js"></script>
        <script src="js/jquery.fs.shifter.min.js"></script>
        <script src="js/jquery.stellar.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/isotope.pkgd.min.js"></script>
        <script src="js/jquery.countTo.js"></script>
        <script src="js/jquery.appear.js"></script>
        
        <script src="js/tweetie.min.js"></script>
        <script src="js/jquery.nav.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/video.js"></script>
        <script src="js/main.js"></script>
        <script type="text/javascript">
            jQuery(document).ready(function() {
                   jQuery('.tp-banner').revolution(
                    {
                        delay:9000,
                        startwidth:1170,
                        startheight:500,
                        fullScreen: 'on',
                        navigationType: 'bullet',
                        navigationArrows: 'none',
                        navigationStyle: 'knight-1',
                        navigationVOffset: 60,
                        hideTimerBar: 'on'
                    });
            });
        </script>
        
    </body>
</html>
