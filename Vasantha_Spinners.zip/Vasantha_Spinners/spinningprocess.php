<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Vasantha Industries Limited</title>
        <meta name="description" content="Responsive Multi-Purpose HTML Template">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#222222"> <!-- Android 5.0 Tab Color -->
        <link rel="shortcut icon" href="./img/favicon.JPG">

        <!-- Google Fonts -->
        <!--<link href='http://fonts.googleapis.com/css?family=Ubuntu:300,400,500' rel='stylesheet' type='text/css'>-->
        <!--<link href='http://fonts.googleapis.com/css?family=Raleway:400,500,600,700' rel='stylesheet' type='text/css'>-->

        <!-- Icon Fonts CSS -->
        <link rel="stylesheet" href="css/knight-iconfont.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!-- <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css"> -->

        <!-- Vendor CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/reset.css">

        <!-- Plugins CSS -->
        <link rel="stylesheet" href="css/jquery.fs.shifter.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/settings.css">
        <link rel="stylesheet" href="css/animate.css">

        <!-- Template CSS -->
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/shortcodes.css">
        <link rel="stylesheet" href="css/custom-bg.css">

        <!-- JS -->
        <script src="js/vendor/modernizr-2.6.2.min.js"></script>
    </head>
    <body oncontextmenu="return false;" class="shifter offcanvas-menu-right offcanvas-menu-dark sticky-header">
        <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

		 
		
		
		
        <!-- mobile-header-wrapper -->
        <div class="mobile-header-wrapper style1 shifter-header clearfix hidden-md hidden-lg">
            <div class="logo-container">
                <a href="index.php" class="logo">
                    <a href="index.php"><img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo"></a>
                </a>
            </div><!-- /logo-container -->
            <div class="shifter-handle style1">
                <a href="#" class="bars">
                    <span></span>
                    <span></span>
                    <span></span>
                </a><!-- /bars -->
            </div><!-- /menu-trigger -->
        </div>
        <!-- /mobile-header-wrapper -->

        <!-- OFF CANVAS MOBILE MENU -->
        <nav class="main-nav offcanvas-menu mobile-nav shifter-navigation fullwidth-items dark-bg">
            <div class="logo-container">
                <a href="index.php"><img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo"></a>
            </div><!-- /logo-container -->
            <form action="#" class="search-form">
                <input type="search" name="mobile-search-form" id="mobile-search-form" placeholder="Search">
                <input type="submit" value="">
            </form>
        </nav>

        <div class="main-wrapper shifter-page">

            <!-- Start main-header -->
            <header class="main-header style2 fixed-header">
                <div class="main-header-inner">
                  
                    <div class="main-bar padding-20 white-bg">
                        <div class="container">
                            <div class="logo-container">
                                <a href="index.php" class="logo">
                                  <img src="./img/vasantha.png" width="150" height="50" alt="vasantha Industries Logo"></a>                                </a>
                            </div><!-- /logo-container -->
                            <div class="menu-container clearfix">
                                <nav class="main-nav active-style1 style1" id="main-nav">
                                    <ul class="clearfix">
                                       
                                        <li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">About Us</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-4 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="vision.php">Vision</a></li>
                                                                <li><a href="journey.php">The Journey</a></li>
                                                          
                                                                <li><a href="welfare.php">Welfare</a></li>
                                                            </ul>
                                                        </div>
                                                       
                                                       
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										 
										 
										  <li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Spinning</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-4 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="spinningquality.php">Quality</a></li>
                                                                <li><a href="spinningprocess.php">Process</a></li>
                                                                <li><a href="spinningmachinery.php">Machinery</a></li>
                                                                <li><a href="spinningproduct.php">Product</a></li>
                                                            </ul>
                                                        </div>
                                                       
                                                       
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										 
										 <li class="dropdown menu">
                                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">Corrugation</a>
                                            <ul class="sub-menu dropdown-menu dark-bg">
                                                <li class="clearfix">
                                                    <div class="clearfix">
                                                        <div class="col-md-2 menu-column">
                                                            <ul class="uppercase arrow-list">
                                                                <li><a href="corrugationquality.php">Quality</a></li>
                                                                <li><a href="corrugationprocess.php">Process</a></li>
                                                                <li><a href="corrugationmachinery.php">Machinery</a></li>
                                                                <li><a href="corrugationproduct.php">Product</a></li>
                                                            </ul>
                                                        </div>
                                                        
                                                        
                                                    </div><!-- /clearfix -->
                                                </li>
                                            </ul>
                                        </li>
										 
										 
                                      
                                       
                                        
                                         <li class="dropdown woocommerce-menu dropdown-menu-left">
                                            <a href="gallery.php">Gallery</a>
                                            
                                            
                                        </li>
										 <li class="dropdown woocommerce-menu dropdown-menu-left">
                                            <a href="contact">Contact</a>
                                            
                                            
                                        </li>
                                    </ul>
                                </nav>
                            </div><!-- /menu-container -->
                        </div><!-- /container -->
                    </div><!-- /main-bar -->
                </div><!-- /main-header-inner -->
 <img src="./img/IMG_9683.jpg" height="350"  width="1400" alt="Knight Client">
            </header>
            <!-- End main-header -->

            
           

            <!-- Start main-section -->
            <section class="main-section">
                <div class="smocky-white-bg padding-top90 padding-bottom65">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 wow fadeInLeft">
                                <header class="section-title section-title-style6">
                                    <h4>Process</h4>
                                    <p>The present activities of the company involve processes that go into producing quality yarn. The best quality raw cotton is processed in state-of-the-art machineries using the latest technical know-how, to produce the finest quality yarn.</p>
                                </header>
                            </div><!-- /col-md-12 -->
                        </div><!-- /row -->
                    </div><!-- /container -->
                </div>
                <div class="icon-box-wrapper icon-box-wrapper-style1 list-icon list-icon-style2 padding-top80 padding-bottom50">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-12 wow fadeInDown">
                                        <div class="icon-box icon-box-style1">
                                            <span class="icon-container">
                                                <i class="icon-knight-300"></i>
                                            </span>
                                            <div class="icon-box-details">
                                                <h6 class="heading-alt-style9">Mixing</h6>
                                                <p>To get an uniform end product consistently from highly variable characteristics of input fibres, mixing of different lots is done. Grading or segregation takes place before mixing to remove unwanted contamination in cotton.</p>
                                            </div><!-- /icon-box-details -->
                                        </div><!-- /icon-box -->
                                    </div><!-- /col-md-12 -->
                                    <div class="col-md-12 wow fadeInDown" data-wow-delay="0.3s">
                                        <div class="icon-box icon-box-style1">
                                            <span class="icon-container">
                                                <i class="icon-knight-201"></i>
                                            </span>
                                            <div class="icon-box-details">
                                                <h6 class="heading-alt-style9">Blow Room</h6>
                                                <p>Blow room consists of a sequence of different machines that carry out Opening, Cleaning, thorough Mixing and decreasing the tuft size smaller and smaller, to feed material to Carding uniformly and continuously.</p>
                                            </div><!-- /icon-box-details -->
                                        </div><!-- /icon-box -->
                                    </div><!-- /col-md-12 -->
                                    <div class="col-md-12 wow fadeInDown">
                                        <div class="icon-box icon-box-style1">
                                            <span class="icon-container">
                                                <i class="icon-knight-356"></i>
                                            </span>
                                            <div class="icon-box-details">
                                                <h6 class="heading-alt-style9">Carding</h6>
                                                <p>Card is the heart of the spinning mill" and "Well carded is half spun" are two proverbs of the experts. The purpose of Carding is to open tufts to individual fibres, neps reduction, elimination of dust and orientation of fibres into sliver form.</p>
                                            </div><!-- /icon-box-details -->
                                        </div><!-- /icon-box -->
                                    </div><!-- /col-md-12 -->
                                    <div class="col-md-12 wow fadeInDown" data-wow-delay="0.3s">
                                        <div class="icon-box icon-box-style1 ">
                                            <span class="icon-container">
                                                <i class="icon-knight-199"></i>
                                            </span>
                                            <div class="icon-box-details">
                                                <h6 class="heading-alt-style9">Br.Drawing</h6>
                                                <p>The object of draw frame is to double and draft the slivers and thereby make even sliver and parallelization of fibres i.e. hooks created at Carding are removed.</p>
                                            </div><!-- /icon-box-details -->
                                        </div><!-- /icon-box -->
                                    </div><!-- /col-md-12 -->
									 <div class="col-md-12 wow fadeInDown" data-wow-delay="0.3s">
                                    <div class="icon-box icon-box-style1 1ast">
                                        <span class="icon-container">
                                            <i class="icon-knight-330"></i>
                                        </span>
                                        <div class="icon-box-details">
                                            <h6 class="heading-alt-style9">Lap Former</h6>
                                            <p>The object of Lap Former is preparation of Lap from slivers with optimum parallelized fibres and feeding of trailing hooks from Carding as leading hooks at Comber to reduce long fibre loss in the noil.</p>
                                        </div><!-- /icon-box-details -->
                                    </div><!-- /icon-box -->
                                </div><!-- /col-md-12 -->
								
								<div class="col-md-12 wow fadeInDown" data-wow-delay="0.3s">
                                    <div class="icon-box icon-box-style1 last">
                                        <span class="icon-container">
                                            <i class="icon-knight-344"></i>
                                        </span>
                                        <div class="icon-box-details">
                                            <h6 class="heading-alt-style9">Comber</h6>
                                            <p>Combing is the process which is used to upgrade the raw material and to produce an improvement in yarn quality by elimination of short fibres, elimination of remaining impurities and elimination of neps.</p>
                                        </div><!-- /icon-box-details -->
                                    </div><!-- /icon-box -->
                                </div><!-- /col-md-12 -->
                                </div><!-- /row -->
                            </div><!-- /col-md-6 -->
                            <div class="col-md-6">
                                <div class="col-md-12 wow fadeInDown">
                                    <div class="icon-box icon-box-style1">
                                        <span class="icon-container">
                                            <i class="icon-knight-324"></i>
                                        </span>
                                        <div class="icon-box-details">
                                            <h6 class="heading-alt-style9">FR.Drawing</h6>
                                            <p>The object of Fr. draw frame is to double and draft the slivers and thereby make even sliver, parallelization of fibres and auto leveling of linear density variations in feeding to get constant linear density of output sliver.</p>
                                        </div><!-- /icon-box-details -->
                                    </div><!-- /icon-box -->
                                </div><!-- /col-md-12 -->
                                <div class="col-md-12 wow fadeInDown" data-wow-delay="0.3s">
                                    <div class="icon-box icon-box-style1">
                                        <span class="icon-container">
                                            <i class="icon-knight-330"></i>
                                        </span>
                                        <div class="icon-box-details">
                                            <h6 class="heading-alt-style9">Simplex</h6>
                                            <p>The object of Simplex is to produce roving suitable to feed Ring frame by means ofattenuation - drafting of sliver, twisting the drafted strand and winding the twisted roving on a bobbin.</p>
                                        </div><!-- /icon-box-details -->
                                    </div><!-- /icon-box -->
                                </div><!-- /col-md-12 -->
                                <div class="col-md-12 wow fadeInDown">
                                    <div class="icon-box icon-box-style1">
                                        <span class="icon-container">
                                            <i class="icon-knight-234"></i>
                                        </span>
                                        <div class="icon-box-details">
                                            <h6 class="heading-alt-style9">Spinning</h6>
                                            <p>Functions of Ring frame are to draft the roving until the required fineness is achieved, to impart strength to the fibre, by inserting twist and to wind up the twisted strand (yarn) in a form suitable for storage, transportation and further processing.</p>
                                        </div><!-- /icon-box-details -->
                                    </div><!-- /icon-box -->
                                </div><!-- /col-md-12 -->
                                <div class="col-md-12 wow fadeInDown" data-wow-delay="0.3s">
                                    <div class="icon-box icon-box-style1 ">
                                        <span class="icon-container">
                                            <i class="icon-knight-344"></i>
                                        </span>
                                        <div class="icon-box-details">
                                            <h6 class="heading-alt-style9">Auto Corner</h6>
                                            <p>The object of Autoconer is to eliminate the faults and contamination in yarn and joining the ends with splice and winding of long and continuous yarn into conical shape to facilitate at further processes.</p>
                                        </div><!-- /icon-box-details -->
                                    </div><!-- /icon-box -->
                                </div><!-- /col-md-12 -->
								<div class="col-md-12 wow fadeInDown" data-wow-delay="0.3s">
                                    <div class="icon-box icon-box-style1">
                                    <div class="icon-box icon-box-style1">
                                        <span class="icon-container">
                                            <i class="icon-knight-344"></i>
                                        </span>
                                        <div class="icon-box-details">
                                            <h6 class="heading-alt-style9">Reeling</h6>
                                            <p>The object of Reeling is to convert yarn in the form of hanks which are mostly suitable for hand looms or dyeing purpose.</p>
                                        </div><!-- /icon-box-details -->
                                    </div><!-- /icon-box -->
                                </div><!-- /col-md-12 -->
								</div>
								
								<div class="col-md-12 wow fadeInDown" data-wow-delay="0.3s">
                                    <div class="icon-box icon-box-style1 last">
                                        <span class="icon-container">
                                            <i class="icon-knight-344"></i>
                                        </span>
                                        <div class="icon-box-details">
                                            <h6 class="heading-alt-style9">Packing</h6>
                                            <p>The object of packing is to check visual defects and pack the material suitable for storage and transportation with necessary labels.</p>
                                        </div><!-- /icon-box-details -->
                                    </div><!-- /icon-box -->
                                </div><!-- /col-md-12 -->
                            </div><!-- /col-md-6 -->
                        </div><!-- /row -->
                    </div><!-- /container -->
                </div><!-- /icon-box-wrapper -->
            </section>
            <!-- End main-section -->


           <!-- Start main-footer -->
            <footer class="main-footer padding-top96 sm-padding-top80 dark-bg">
                <div class="container">
                    <div class="row">
                       <div style="color:white;" class="col-md-4">
                            <div class="widget widget-contact-info widget-contact-info-style2">
                                <h6 class="">Corporate Office</h6>
                                <address>
                                    <p>
									 </strong>Vasantha House, Survey No 79,
Hafeezpet, Serilingampally Mandal,Hyderabad
                                    </p>
                                   
                                    <p>
                                        <strong>Phone Number</strong>
                                        <span>9502776111/9502778111 </span>
                                       
                                    </p>
									
                                </address>
                            </div><!-- /widget-contact-info -->
                        </div><!-- /col-md-3 -->
                   
                        <div style="color:white;" class="col-md-8">
                            <div class="widget widget-contact-info widget-contact-info-style2">
                               <center> <h6>Regd. Office & Factory</h6>
                                <address>
                                    <p>
									D. No. 4-383/2,  Vasantha Industries Limited
                        NH-16(old NH-5), Thimmapuram Village,<br >
                        Edlapadu Mandal, Guntur District - 522233,Andhra Pradesh
                                       
                                    </p>
                                   
                                    <p>
                                        <strong>Phone Number</strong>
                                        <span> +91 - 8647 - 276668 , 276669</span>
                                       
                                    </p>
									 
                                    <p>
                                        <strong>Email Address</strong>
                                        <a href="mailto:info@vasanthaspinners.com"><u>info@vasanthaspinners.com</u></a>
                                    </p></center>
                                </address>
                            </div><!-- /widget-contact-info -->
                        </div><!-- /col-md-3 -->
                      
					  
                      
					  
					  
                    </div><!-- /row -->
                </div><!-- /container -->
               
            </footer>
            <!-- End main-footer -->
          
           

           
           

         
            
        </div><!-- /main-wrapper -->

        <!-- JS -->
        <script src="js/vendor/jquery.min.js"></script>
        <script src="js/jquery.themepunch.tools.min.js"></script>
        <script src="js/jquery.themepunch.revolution.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/imagesloaded.pkgd.min.js"></script>
        <script src="js/jquery.fs.shifter.min.js"></script>
        <script src="js/jquery.stellar.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/jquery.nav.js"></script>
        <script src="js/wow.min.js"></script>
        <script src="js/main.js"></script>
        <script type="text/javascript">
            jQuery(document).ready(function() {
                   jQuery('.tp-banner').revolution(
                    {
                        delay:9000,
                        startwidth:1170,
                        startheight:500,
                        fullScreen: 'on',
                        navigationType: 'none',
                        navigationArrows: 'solo',
                        navigationStyle: 'knight',
                        hideTimerBar: 'on'
                    });
            });
        </script>
        
    </body>
</html>
