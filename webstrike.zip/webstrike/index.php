<?php 
require_once('core/config/config.php');
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="shortcut icon" href="images/favicon.png">
	<title>THE WEBSTRIKE | HOME</title>
	<!-- Bootstrap Core CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/fontawesome/css/font-awesome.min.css" type="text/css" rel="stylesheet">
	<link href="css/animate.min.css" rel="stylesheet">
	<!-- Vendor css -->
	<link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">
	<!-- Template base -->
	<link href="css/theme-base.css" rel="stylesheet">
	<!-- Template elements -->
	<link href="css/theme-elements.css" rel="stylesheet">
	<!-- Responsive classes -->
	<link href="css/responsive.css" rel="stylesheet">
	<!-- Template color -->
	<link href="css/color-variations/blue.css" rel="stylesheet" type="text/css" media="screen" title="blue">
	<!-- LOAD GOOGLE FONTS -->
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,800,700,600%7CRaleway:100,300,600,700,800" rel="stylesheet" type="text/css" />
	<!-- SLIDER REVOLUTION 5.x CSS SETTINGS -->
	<link rel="stylesheet" property="stylesheet" href="vendor/rs-plugin/css/settings.css" type="text/css" media="all" />
	<!-- CSS CUSTOM STYLE -->
    <link rel="stylesheet" type="text/css" href="css/custom.css" media="screen" />
    <style>
    section {
    padding: 30px 0 !important;
	}
    </style>
    <!--VENDOR SCRIPT-->
    <script src="js/jquery-1.11.2.min.js"></script>
    <script src="js/plugins-compressed.js"></script>
</head>

<body class="wide">
	<!-- WRAPPER -->
	<div class="wrapper">
		<!-- HEADER -->
		<header id="header" class="header-transparent header-fullwidth">
			<div id="header-wrap">
				<div class="container">
					
					<!--LOGO-->
					<div id="logo">
						<a href="index.php" class="logo" data-dark-logo="images/logo-dark.png">
							<img src="images/logo.png" alt="Polo Logo">
						</a>
					</div>
					<!--END: LOGO-->

					<!--MOBILE MENU -->
					<div class="nav-main-menu-responsive">
						<button class="lines-button x">
							<span class="lines"></span>
						</button>
					</div>
					<!--END: MOBILE MENU -->
					     <!--NAVIGATION-->
        <div class="navbar-collapse collapse main-menu-collapse navigation-wrap">
          <div class="container">
            <nav id="mainMenu" class="main-menu mega-menu">
              <ul class="main-menu nav nav-pills">
                <li><a href="index.php"><i class="fa fa-home"></i></a> </li>
                <li><a href="services.php">SERVICES</a></li>    
              </ul>
            </nav>
          </div>
        </div>
        <!--END: NAVIGATION-->			
				</div>
			</div>
		</header>
		<!-- END: HEADER -->

		<!-- REVOLUTION SLIDER -->
		<div id="slider">

<div id="rev_slider_21_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="Polo Design Studio" style="background-color:transparent;padding:0px;">
<!-- START REVOLUTION SLIDER 5.1 fullscreen mode -->
	<div id="rev_slider_21_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.1">
<ul>	<!-- SLIDE  -->
	<li data-index="rs-98" data-transition="fade" data-slotamount="default"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-description="">
		<!-- MAIN IMAGE -->
		<img src="homepages/design-studio/images/slider/ambient.jpg"  alt=""  width="1680" height="1050" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="2" class="rev-slidebg" data-no-retina>
		<!-- LAYERS -->

		<!-- LAYER NR. 1 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 
			 id="slide-98-layer-2" 
			 data-x="['center','center','center','center']" data-hoffset="['0','0','-4','-2']" 
			 data-y="['top','top','top','top']" data-voffset="['637','637','700','586']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:1520;e:Power4.easeInOut;" 
			 data-transform_out="opacity:0;s:230;s:230;" 
			data-start="500" 
			data-responsive_offset="on" 

			
			style="z-index: 5;"><img src="homepages/design-studio/images/slider/table.png" alt="" width="1300" height="297" data-ww="['1300px','1300px','1300px','1300px']" data-hh="['297px','297px','297px','297px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 2 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 
			 id="slide-98-layer-11" 
			 data-x="['center','center','center','center']" data-hoffset="['338','338','313','396']" 
			 data-y="['top','top','top','top']" data-voffset="['621','621','691','572']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="y:top;s:2000;e:Power2.easeOut;" 
			 data-transform_out="opacity:0;s:300;s:300;" 
			data-start="3870" 
			data-responsive_offset="on" 

			
			style="z-index: 6;"><img src="homepages/design-studio/images/slider/headphone_3.png" alt="" width="150" height="70" data-ww="['139px','139px','139px','139px']" data-hh="['65px','65px','65px','65px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 3 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 
			 id="slide-98-layer-4" 
			 data-x="['center','center','center','center']" data-hoffset="['0','0','0','6']" 
			 data-y="['top','top','top','top']" data-voffset="['350','350','402','302']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="y:top;s:2100;e:Power2.easeOut;" 
			 data-transform_out="opacity:0;s:1.875;s:1.875;" 
			data-start="1471.875" 
			data-responsive_offset="on" 

			
			style="z-index: 7;"><img src="homepages/design-studio/images/slider/apple_monitor_1.png" alt="" width="502" height="384" data-ww="['411px','411px','411px','411px']" data-hh="['315px','315px','315px','315px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 4 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 
			 id="slide-98-layer-6" 
			 data-x="['center','center','center','center']" data-hoffset="['-5','-5','-16','-16']" 
			 data-y="['top','top','top','top']" data-voffset="['671','671','726','726']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="y:top;s:2000;e:Power2.easeOut;" 
			 data-transform_out="opacity:0;s:300;s:300;" 
			data-start="2990" 
			data-responsive_offset="on" 

			
			style="z-index: 8;"><img src="homepages/design-studio/images/slider/keyboard_apple_1-220x23.png" alt="" width="220" height="23" data-ww="['220px','220px','220px','220px']" data-hh="['23px','23px','23px','23px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 5 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 
			 id="slide-98-layer-14" 
			 data-x="['left','left','left','left']" data-hoffset="['432','324','202','57']" 
			 data-y="['top','top','top','top']" data-voffset="['366','365','416','319']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="z:0;rX:0deg;rY:0;rZ:0;sX:2;sY:2;skX:0;skY:0;opacity:0;s:1000;e:Power2.easeOut;" 
			 data-transform_out="opacity:0;s:300;s:300;" 
			 data-mask_in="x:0px;y:0px;" 
			data-start="3870" 
			data-responsive_offset="on" 

			
			style="z-index: 9;"><img alt="" width="1663" height="892" data-ww="['378px','378px','378px','378px']" data-hh="['214px','214px','214px','214px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 6 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 
			 id="slide-98-layer-7" 
			 data-x="['center','center','center','center']" data-hoffset="['-397','-397','-273','-201']" 
			 data-y="['top','top','top','top']" data-voffset="['603','603','675','552']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="y:top;s:2000;e:Power2.easeOut;" 
			 data-transform_out="opacity:0;s:300;s:300;" 
			data-start="3200" 
			data-responsive_offset="on" 

			
			style="z-index: 10;"><img src="homepages/design-studio/images/slider/camera_canon_d40_1.png" alt="" width="129" height="105" data-ww="['113px','113px','113px','113px']" data-hh="['92px','92px','92px','92px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 7 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 
			 id="slide-98-layer-9" 
			 data-x="['center','center','center','center']" data-hoffset="['-264','-264','-187','-123']" 
			 data-y="['top','top','top','top']" data-voffset="['625','625','680','586']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="y:top;s:2000;e:Power2.easeOut;" 
			 data-transform_out="opacity:0;s:300;s:300;" 
			data-start="3600" 
			data-responsive_offset="on" 

			
			style="z-index: 11;"><img src="homepages/design-studio/images/slider/mug_1.png" alt="" width="87" height="75" data-ww="['71px','71px','71px','71px']" data-hh="['62px','62px','62px','62px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 8 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 
			 id="slide-98-layer-10" 
			 data-x="['center','center','center','center']" data-hoffset="['199','199','174','118']" 
			 data-y="['top','top','top','top']" data-voffset="['656','656','715','606']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="y:top;s:2000;e:Power2.easeOut;" 
			 data-transform_out="opacity:0;s:300;s:300;" 
			data-start="3330" 
			data-responsive_offset="on" 

			
			style="z-index: 12;"><img src="homepages/design-studio/images/slider/mouse_apple_1.png" alt="" width="76" height="44" data-ww="['63px','63px','63px','63px']" data-hh="['37px','37px','37px','37px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 9 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-2" 
			 id="slide-98-layer-12" 
			 data-x="['center','center','center','center']" data-hoffset="['379','379','303','172']" 
			 data-y="['top','top','top','top']" data-voffset="['-21','-21','-17','-2']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="y:top;s:2000;e:Power2.easeOut;" 
			 data-transform_out="opacity:0;s:300;s:300;" 
			data-start="2430" 
			data-responsive_offset="on" 

			
			style="z-index: 13;"><img src="homepages/design-studio/images/slider/pendant_1-220x504.png" alt="" width="220" height="504" data-ww="['133px','133px','133px','133px']" data-hh="['434px','434px','434px','434px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 10 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" 
			 id="slide-98-layer-13" 
			 data-x="['center','center','center','center']" data-hoffset="['-524','-431','-323','-480']" 
			 data-y="['top','top','top','top']" data-voffset="['121','128','195','115']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="opacity:0;s:2000;e:Power2.easeOut;" 
			 data-transform_out="opacity:0;s:290;s:290;" 
			data-start="670" 
			data-responsive_offset="on" 

			
			style="z-index: 14;"><img src="homepages/design-studio/images/slider/frame_black_design_pattern_4-220x230.png" alt="" width="220" height="230" data-ww="['220px','220px','176','220px']" data-hh="['230px','230px','184','230px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 11 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-2" 
			 id="slide-98-layer-15" 
			 data-x="['center','center','center','center']" data-hoffset="['-572','-572','-416','-416']" 
			 data-y="['top','top','top','top']" data-voffset="['621','621','654','654']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="y:50px;opacity:0;s:1500;e:Power3.easeInOut;" 
			 data-transform_out="opacity:0;s:140;s:140;" 
			data-start="3420" 
			data-responsive_offset="on" 

			
			style="z-index: 15;"><img src="homepages/design-studio/images/slider/chair_2-220x187.png" alt="" width="460" height="392" data-ww="['400px','400px','400px','400px']" data-hh="['341px','341px','341px','341px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 12 -->
		<div class="tp-caption   tp-resizeme rs-parallaxlevel-2" 
			 id="slide-98-layer-19" 
			 data-x="['right','right','right','right']" data-hoffset="['-339','-339','-334','-334']" 
			 data-y="['top','top','top','top']" data-voffset="['201','201','502','502']" 
						data-width="none"
			data-height="none"
			data-whitespace="nowrap"
			data-transform_idle="o:1;"
 
			 data-transform_in="opacity:0;s:1500;e:Power3.easeInOut;" 
			 data-transform_out="opacity:0;s:290;s:290;" 
			data-start="3870" 
			data-responsive_offset="on" 

			
			style="z-index: 16;"><img src="homepages/design-studio/images/slider/plant1.png" alt="" width="700" height="844" data-ww="['700px','700px','700px','700px']" data-hh="['844px','844px','844px','844px']" data-no-retina> 
		</div>

		<!-- LAYER NR. 13 -->
		<div class="tp-caption medium_light_black   tp-resizeme rs-parallaxlevel-1" 
			 id="slide-98-layer-20" 
			 data-x="['center','center','center','center']" data-hoffset="['9','9','10','0']" 
			 data-y="['top','top','top','top']" data-voffset="['83','83','42','82']" 
						data-fontsize="['80','80','66','50']"
			data-lineheight="['78','78','78','50']"
			data-width="['637','637','637','465']"
			data-height="['186','186','186','190']"
			data-whitespace="normal"
			data-transform_idle="o:1;"
 
			 data-transform_in="y:[100%];z:0;rZ:-35deg;sX:1;sY:1;skX:0;skY:0;s:2000;e:Power4.easeInOut;" 
			 data-transform_out="opacity:0;s:300;s:300;" 
			 data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" 
			data-start="3870" 
			data-splitin="chars" 
			data-splitout="none" 
			data-responsive_offset="on" 

			data-elementdelay="0.05" 
			
			style="z-index: 17; min-width: 637px; max-width: 637px; max-width: 186px; max-width: 186px; white-space: normal; font-size: 80px; line-height: 78px; font-weight: 100; color: rgba(0, 0, 0, 1.00);text-align:center;padding:0px 0px 0px 0px;border-color:rgba(255, 214, 88, 1.00);">The Difference is Hand Crafted 
		</div>

		<!-- LAYER NR. 14 -->
		<div class="tp-caption medium_light_black   tp-resizeme rs-parallaxlevel-1" 
			 id="slide-98-layer-21" 
			 data-x="['center','center','center','center']" data-hoffset="['16','16','23','0']" 
			 data-y="['top','top','top','top']" data-voffset="['249','249','221','221']" 
						data-fontsize="['26','26','20','20']"
			data-lineheight="['26','26','20','20']"
			data-width="['637','637','465','465']"
			data-height="['none','none','125','125']"
			data-whitespace="normal"
			data-transform_idle="o:1;"
 
			 data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeInOut;" 
			 data-transform_out="opacity:0;s:300;s:300;" 
			data-start="3870" 
			data-splitin="none" 
			data-splitout="none" 
			data-responsive_offset="on" 

			
			style="z-index: 18; min-width: 637px; max-width: 637px; white-space: normal; font-size: 26px; line-height: 26px; font-weight: 100; color: rgba(0, 0, 0, 1.00);text-align:center;padding:0px 0px 0px 0px;border-color:rgba(255, 214, 88, 1.00);"
		</div>
	</li>
</ul>
<div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>	</div>
</div><!-- END REVOLUTION SLIDER -->
		
		
		</div>
		<!-- END REVOLUTION SLIDER -->

		<!-- ABOUT CAFFE -->
		<section>
			<div class="container">

				<div class="row">
					<div class="col-md-7" data-animation="fadeIn">
						<h2>HELLO, WE ARE THE WEBSTRIKE</h2>
						<p style="text-align:justify;">The WebStrike was started with the core mission of providing high-quality design, web solutions that work, and personal service. We take on projects both big and small, work with a diverse set of clients, and really enjoy hammering out problems and getting results. We can be your creative team or work to support your in-house people. Guaranteed, we are here for the long haul.</p>
<p style="text-align:justify;">
The WebStrike excels at custom design, front end development. We love taking on challenging projects that require full-on content strategy, thoughtful design, demanding development, and ongoing marketing. And we take your small problems seriously. Have a website that is down, an important message that needs announcing, or something that needs to be fixed? We take pride in providing fast, responsive turnaround times to your immediate needs.</p>
							
						
					</div>
					<div class="col-md-3">
					<center><img style="width: 90%;margin-left: 147px;margin-top: 46px;" src="images/logo.png"></img></center>
					</div>
				</div>
			</div>
		</section>
		<!-- END: ABOUT CAFFE -->

		<!-- PORTFOLIO -->
		<section class="p-b-0">
			<div class="container">
				<div class="hr-title hr-long center"><abbr>WHAT WE DO</abbr> </div>
			</div>
			<div class="portfolio">
				<!-- Portfolio Items -->
				<div id="isotope1" class="isotope portfolio-items" data-isotope-item-space="0" data-isotope-mode="masonry" data-isotope-col="4" data-isotope-item=".portfolio-item">
					<div class="portfolio-item design artwork">
						<div class="image-box effect victor"> <img src="images/designing.jpg" alt="">
							<div class="image-box-content">
								<h3>DESIGNING</h3>
							</div>
						</div>
					</div>
					<div class="portfolio-item design beauty">
						<div class="image-box effect victor"> <img src="images/development.jpg" alt="">
							<div class="image-box-content">
								<h3>DEVELOPMENT</h3>
								
							</div>
						</div>
					</div>
					<div class="portfolio-item design beauty">
						<div class="image-box effect victor"> <img src="images/strategys.jpg" alt="">
							<div class="image-box-content">
								<h3>STRATEGY</h3>
							</div>
						</div>
					</div>
					<div class="portfolio-item design artwork">
						<div class="image-box effect victor"> <img src="images/strategy.jpg" alt="">
							<div class="image-box-content">
								<h3>DIGITAL MARKETING</h3>
							</div>
						</div>
					</div>					
				</div>
				<!-- END: Portfolio Items -->

			</div>
		</section>
		<!-- END: PORTFOLIO -->

		<!-- FOOTER -->
		<footer class="background-dark text-grey" id="footer">
			<div class="footer-content">
				<div class="container">
					<div class="row">
						<div class="col-md-4">
							<div class="widget clearfix widget-contact-us" style="background-image: url('images/world-map.png'); background-position: 50% 55px; background-repeat: no-repeat">
								<h4 class="widget-title">Contact us</h4>
								<ul class="list-large list-icons">
									<li><i class="fa fa-map-marker"></i>
										<strong>Address:</strong> 503, Park Avenue Matrix Homes,
										<br>Patrika Nagar, Street-1, Madhapur-500081</li>
									<li><i class="fa fa-phone"></i><strong>Phone:</strong> +91 9133222230 </li>
									<li><i class="fa fa-envelope"></i><strong>Email:</strong> info@thewebstrike.com	</li>
									<li><i class="fa fa-clock-o"></i>Monday - Friday: <strong>10:00 - 22:00</strong>
										<br>Saturday, Sunday: <strong>Closed</strong>
									</li>
								</ul>
							</div>
						</div>		
					</div>
				</div>
			</div>
			<div class="copyright-content">
				<div class="container">
					<div class="row">
						<div class="copyright-text col-md-6"> &copy;2016 The WebStrike. All Rights Reserved.</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- END: FOOTER -->

	</div>
	<!-- END: WRAPPER -->

	<!-- GO TOP BUTTON -->
	<button class="gototop gototop-button" data-target="#modal" data-toggle="modal" href="#">Quote Here</button>
	<div class="modal fade" id="modal" tabindex="-1" role="modal" aria-labelledby="modal-label" aria-hidden="true" style="display: none;">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
<h4 class="modal-title" id="modal-label">Add Quotation</h4>
</div>
<div class="modal-body">
 <form id="formvalidate">
 <div class="form-group">
<label class="form-label">Email</label>
<div class="controls">
<input required type="text" class="form-control" name="email" id="email" placeholder="enter your email address">
</div>
</div>
<div class="form-group">
<label class="form-label">Mobile No</label>
<div class="controls">
<input required type="text" class="form-control" id="mobileno" name="mobileno" placeholder="enter your Mobile No">
</div>
</div>
<div class="form-group">
<label class="form-label">Add Requirements</label>
<div class="controls">
<textarea required type="text" cols="5" class="form-control" name="addreq" id="addreq" placeholder="enter your Requirements"></textarea>
</div>
</div>
    <button type="button" id="send" class="btn btn-primary">send</button>
            
        </form>
</div>
</div>
</div>
</div>
</li>
	<!-- SLIDER REVOLUTION 5.x SCRIPTS  -->
	<script src="//cdnjs.cloudflare.com/ajax/libs/validate.js/0.10.0/validate.min.js"></script>
	<script type="text/javascript" src="vendor/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
	<script type="text/javascript" src="vendor/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
	<script type="text/javascript">
               $(document).ready(function(){
                    $("#send").click(function(){
 
                          var email=$("#email").val();
                          var mobileno=$("#mobileno").val();
                          var addreq=$("#addreq").val();
 
                          $.ajax({
                              type:"post",
                              url:"core/parts/ajax_signup.php",
                              data:"email="+email+"&mobileno="+mobileno+"&addreq="+addreq,
                              success:function(data){
                                 alert(data);
                              }
 
                          });
 
                    });
               });
       </script>
 
    <script type="text/javascript">
						var tpj=jQuery;
			
			var revapi21;
			tpj(document).ready(function() {
				if(tpj("#rev_slider_21_1").revolution == undefined){
					revslider_showDoubleJqueryError("#rev_slider_21_1");
				}else{
					revapi21 = tpj("#rev_slider_21_1").show().revolution({
						sliderType:"standard",
jsFileLocation:"vendor/rs-plugin/js/",
						sliderLayout:"fullscreen",
						dottedOverlay:"none",
						delay:9000,
						navigation: {
							onHoverStop:"off",
						},
						responsiveLevels:[1240,1024,778,480],
						visibilityLevels:[1240,1024,778,480],
						gridwidth:[1240,1024,778,480],
						gridheight:[868,768,960,720],
						lazyType:"none",
						parallax: {
							type:"mouse",
							origo:"slidercenter",
							speed:700,
							levels:[2,6,10,20,25,30,35,40,45,50,47,48,49,50,51,55],
							type:"mouse",
							disable_onmobile:"on"
						},
						shadow:0,
						spinner:"spinner0",
						stopLoop:"off",
						stopAfterLoops:-1,
						stopAtSlide:-1,
						shuffle:"off",
						autoHeight:"off",
						fullScreenAutoWidth:"off",
						fullScreenAlignForce:"off",
						fullScreenOffsetContainer: "",
						fullScreenOffset: "",
						disableProgressBar:"on",
						hideThumbsOnMobile:"off",
						hideSliderAtLimit:0,
						hideCaptionAtLimit:0,
						hideAllCaptionAtLilmit:0,
						debugMode:false,
						fallbacks: {
							simplifyAll:"off",
							nextSlideOnWindowFocus:"off",
							disableFocusListener:false,
						}
					});
				}
			});	/*ready*/
		</script>
	<!-- Theme Base, Components and Settings -->
	<script src="js/theme-functions.js"></script>
	<!-- Custom js file -->
	<script src="js/custom.js"></script>
</body>
</html>
