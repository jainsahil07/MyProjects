<!DOCTYPE html>
<html lang="en">

<head>
	<link rel="shortcut icon" href="images/favicon.png">
	<title>THE WEBSTRIKE | SERVICES</title>

	<!-- Bootstrap Core CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="vendor/fontawesome/css/font-awesome.min.css" type="text/css" rel="stylesheet">
	<link href="css/animate.min.css" rel="stylesheet">

	<!-- Vendor css -->
	<link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/magnific-popup.css" rel="stylesheet">

	<!-- Template base -->
	<link href="css/theme-base.css" rel="stylesheet">

	<!-- Template elements -->
	<link href="css/theme-elements.css" rel="stylesheet">	
    
    
	<!-- Responsive classes -->
	<link href="css/responsive.css" rel="stylesheet">	

	<!-- Template color -->
	<link href="css/color-variations/blue.css" rel="stylesheet" type="text/css" media="screen" title="blue">

	<!-- LOAD GOOGLE FONTS -->
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,800,700,600%7CRaleway:100,300,600,700,800" rel="stylesheet" type="text/css" />

	<!-- CSS CUSTOM STYLE -->
    <link rel="stylesheet" type="text/css" href="css/custom.css" media="screen" />

    <!--VENDOR SCRIPT-->
    <script src="js/jquery-1.11.2.min.js"></script>
    <script src="js/plugins-compressed.js"></script>
</head>

<body class="wide">
	<!-- WRAPPER -->
	<div class="wrapper">

		<!-- HEADER -->
		<header id="header" class="header-transparent header-fullwidth">
			<div id="header-wrap">
				<div class="container">
					<!--LOGO-->
					<div id="logo">
						<a href="index.php" class="logo" data-dark-logo="images/logo-dark.png">
							<img src="images/logo.png" alt="Polo Logo">
						</a>
					</div>
					<!--END: LOGO-->

					<!--MOBILE MENU -->
					<div class="nav-main-menu-responsive">
						<button class="lines-button x">
							<span class="lines"></span>
						</button>
					</div>
					<!--END: MOBILE MENU -->

					<!--NAVIGATION-->
        <div class="navbar-collapse collapse main-menu-collapse navigation-wrap">
          <div class="container">
            <nav id="mainMenu" class="main-menu mega-menu">
                <ul class="main-menu nav nav-pills">
                    <li><a href="index.php"><i class="fa fa-home"></i></a> </li>
                    <li><a href="services.php">SERVICES</a></li> 
                </ul>
            </nav>
          </div>
        </div>
                    <!--END: NAVIGATION-->	
				</div>
			</div>
		</header>
		<!-- END: HEADER -->
    
<!-- PAGE TITLE -->
<section id="page-title" class="page-title-parallax page-title-center text-dark" style="background-image:url(images/parallax/page-title-parallax.jpg);">
    <div class="container">
        <div class="page-title col-md-8">
            <h1>SERVICES</h1>
        </div>
    </div>
</section>
<!-- END: PAGE TITLE -->

<!-- SECTION -->
<section>
    <div class="container portfolio">
        <!--Portfolio Filter-->
        <div class="filter-active-title">Show All</div>
        <ul class="portfolio-filter" id="portfolio-filter" data-isotope-nav="isotope">
			<li class="ptf-active" data-filter="*">Show All</li>
			<li data-filter=".artwork">Designing</li>
			<li data-filter=".banner">Development</li>
			<li data-filter=".beauty">Strategy</li>
			<li data-filter=".marketing">Digital Marketing</li>
		</ul>
        <!-- END: Portfolio Filter -->
        <!-- Portfolio Items -->
        <div id="isotope" class="isotope portfolio-items" data-isotope-item-space="3" data-isotope-mode="masonry" data-isotope-col="3" data-isotope-item=".portfolio-item">
            <div class="portfolio-item design artwork">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/1.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>    
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">Logo Design</h4>     
                </div>    
            </div>

            <div class="portfolio-item design artwork">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/2.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>     
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">Responsive Web Design</h4>
                </div>  
            </div>

            <div class="portfolio-item design artwork">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/3.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>   
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">Web Apps</h4>
                </div>   
            </div>

            <div class="portfolio-item design artwork">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/41.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>     
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">Ecommerce Platform & Banner Design</h4>
                </div> 
            </div>

            <div class="portfolio-item artwork">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/5.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>     
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">Ad Design</h4> 
                </div>    
            </div>

            <div class="portfolio-item design banner">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/8.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>  
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">CMS</h4>   
                </div>    
            </div>
        
            <div class="portfolio-item design banner">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/9.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>     
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">OpenCart Development</h4>  
                </div>   
            </div>

            <div class="portfolio-item design beauty">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/10.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>         
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">Business Analysis</h4>   
                </div> 
            </div>

            <div class="portfolio-item design beauty">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/7.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>        
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">Competitor Analysis</h4>  
                </div>  
            </div>


            <div class="portfolio-item design beauty">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/11.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>        
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">Campaign Srategy</h4>     
                </div> 
            </div>
          
               <div class="portfolio-item design marketing">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/13.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>      
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">SEO</h4>  
                </div> 
            </div>

               <div class="portfolio-item design marketing">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/12.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>       
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">SMO</h4> 
                </div>  
            </div>

             <div class="portfolio-item design marketing">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/16.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a> 
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">SEM</h4>    
                </div>     
            </div>
           
             <div class="portfolio-item design marketing">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/17.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">SMM</h4>
                </div>    
            </div>

             <div class="portfolio-item design marketing">
                <div class="portfolio-image effect social-links">
                    <img src="images/portfolio/15.jpg" alt="">
                    <div class="image-box-content">
                        <p>
                            <a href="images/portfolio/1.jpg"></a>   
                        </p>
                    </div>
                </div>
                <div class="portfolio-description">
                    <h4 class="title">Email marketing</h4> 
                </div>    
            <div>

            
            </div>
        <!-- END: Portfolio Items -->
    </div>  
</section>

		<!-- FOOTER -->
		<footer class="background-dark text-grey" id="footer">
			<div class="footer-content">
				<div class="container">	
					<div class="row">
						<div class="col-md-4">
							<div class="widget clearfix widget-contact-us" style="background-image: url('images/world-map.png'); background-position: 50% 55px; background-repeat: no-repeat">
								<h4 class="widget-title">Contact us</h4>
								<ul class="list-large list-icons">
                                    <li><i class="fa fa-map-marker"></i>
                                        <strong>Address:</strong> 503, Park Avenue Matrix Homes,
                                        <br>Patrika Nagar, Street-1, Madhapur-500081</li>
                                    <li><i class="fa fa-phone"></i><strong>Phone:</strong> +91 9133222230 </li>
                                    <li><i class="fa fa-envelope"></i><strong>Email:</strong> info@thewebstrike.com </li>
                                    <li><i class="fa fa-clock-o"></i>Monday - Friday: <strong>10:00 - 22:00</strong>
                                        <br>Saturday, Sunday: <strong>Closed</strong>
                                    </li>
                                </ul>
							</div>
						</div>	
					</div>
				</div>
			</div>
			<div class="copyright-content">
				<div class="container">
					<div class="row">
						<div class="copyright-text col-md-6"> &copy; 2016 The WebStrike. All Rights Reserved.</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- END: FOOTER -->
</div>
<!-- END: WRAPPER -->


	<!-- Theme Base, Components and Settings -->
	<script src="js/theme-functions.js"></script>
    <!-- Custom js file -->
    <script src="js/custom.js"></script>
</body>
</html>
