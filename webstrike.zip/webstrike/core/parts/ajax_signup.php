<?php 
  require '../mail/Send_Mail.php';

 // mysql_connect("localhost","root","");
 //  mysql_select_db("webstrike");
 
  $email=$_POST["email"];
  $mobileno=$_POST["mobileno"];
   $addreq=$_POST["addreq"];
 
  // $query=mysql_query("INSERT INTO webstrike_quotation(email,mobileno,addreq) values('$email','$mobileno','$addreq') ");
 
  // if($query){
  //   echo "Your Quotation has been sent";
  // }
  // else{
  //   echo "Error in sending your Quotation";
  // }



$to = "vikas@thewebstrike.com";
$subject = "received your quotation";
$body = "Email: $email <br> MobileNo: $mobileno <br> Quotation:$addreq "; // HTML  tags
$status=Send_Mail($to,$subject,$body);
// echo $status;
if(!$status )//|| !$query )
    echo "NOT SENT";
else
    echo "SENT";
?>