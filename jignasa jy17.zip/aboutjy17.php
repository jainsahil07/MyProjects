<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

	
<!-- Mirrored from gj-designs.in/universal/about.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:52:30 GMT -->
<head>
	    <!-- Your Basic Site Informations -->
		<title>Jignasa Yaan-17</title>
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- Stylesheets -->
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.theme.css" />
		<link rel="stylesheet" type="text/css" href="css/cubeportfolio.css">

		<!-- REVOLUTION BANNER CSS SETTINGS -->
		<link rel="stylesheet" type="text/css" href="rs-plugin/css/settings.css" media="screen" />

		<!-- Google fonts -->
		<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
		
		<!-- Font Awesome -->
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css" />

		<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->
		
	</head>
	<body>
	
		<!--Header-->
		<header>
			<div class="header2">
		
			
		
		
				
				<nav class="navbar navbar-default">
					<div class="container container-fluid">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="index.php"><img style="margin-top:-12px;" src="images/logo.png" alt="" /> </a>
						</div>
						
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<li>
									<a href="index.php">Home</a>
									<ul class="for-mob-menu">
										<li><a href="index.php" class="active">Home</a></li>
									</ul>
								</li>
								
								
								
								<li>
									<a href="about.php" >About Us</a>
									<ul class="for-mob-menu">
										<li><a href="about.php">About Us</a></li>
									</ul>
								</li>
								<li>
									<a href="aboutjy17.php"  class="active">About JY17</a>
									<ul class="for-mob-menu">
										<li><a href="about.php">About Us</a></li>
									</ul>
								</li>
								
								
								<li>
									<a href="rulesandregulations.php">Rules and Regulations <span class="caret"></span></a>
									
									
								</li>
								
								
								
								
								
								
								<li>
									<a href="register.php" >Register</a>
									<ul class="for-mob-menu">
										<li><a href="register.php">Register</a></li>
									</ul>
								</li>
								<li>
									<a href="contact.php" >Contact</a>
									<ul class="for-mob-menu">
										<li><a href="contact.php">Contact</a></li>
									</ul>
								</li>
								
							</ul>
							
							
							
						</div><!-- /.navbar-collapse -->
						
						
					</div><!-- /.container-fluid -->
				</nav>
		
		
		
		</div>
		
		</header>
		<!-- End Header Section -->
		
		<!-- Start About Main Section -->
		<div class="about-main">
			<div class="container">
				<div class="col-md-12">
					<h2>ABOUT <span>JY17</span></h2>
					<div class="under-h2">OUR MISSION IS TO PROVIDE BEST QUALITY WORK.</div>
					<p style="text-align:justify;"><b>The details of the JIGNASA YAAN  17 are as follows:</b>

<p>JIGNASA YAAN 17  was intended to promote Ek Bharath Shresta Bharath Theme .</p>

<p>As a part of JIGNASA YAAN 17, the student delegates of the YAAN who shall be termed as
YAANIKS  shall participate in the Annual Inter Collegiate Initiative of IIM Ahmedabad.</p>

<p><b>DATES of THE FESTIVAL:  January25-30,2017</b></p>

<div class="under-h2">Activities as a part of the JIGNASA YAAN 17 are:</div>

<h5>Events on Train [To & FRO Journey] :</h5>

<ul>
<p><i class="fa fa-check"></i> Students shall be categorised in teams of 15 members.</p>

<p><i class="fa fa-check"></i> Each Team shall have a Mentor. Mentors  are from Corporate Field and from elite institutions 
 Who held various roles such as Entrepreneurs, HR Managers, Developers, Project Managers,
Technical Leads, Resource persons who had elite innovative creative backgrounds .</p>

<p><i class="fa fa-check"></i> Each Team contains representatives, delegates from all the participant colleges.</p>

<p><b> With the support of mentors Activities YAANIKS are engaged in various activities such as:</b></p>
<p><i class="fa fa-check"></i> Decorating the BHOGI of the Train with UNESCO Theme.</p> 
<p><i class="fa fa-check"></i> Mana Chandamama Kathalu: Short Skits on CHANDAMAMA Stories.</p>  
<p><i class="fa fa-check"></i><b> Edupreneurship:</b> Need of the hour, Fine Arts, Culture, Heritage Entrepreneurship Building Activities.</p>
<p><i class="fa fa-check"></i> Creative Talks</p>
<p><i class="fa fa-check"></i><b> Meet Your Mentors :</b> Mentors interacting with the YAANIKS and guiding them regarding the Career opportunities , Campus placements procedure, preparation and opportunities.</p>
</ul> 


<h5>Events off  Train:</h5>
<ul>
<p style="text-align:justify;"><i class="fa fa-check"></i> The YAANIKS are engaged to participate in  events at IIM Ahmedabad, Annual Festival of  for their permitted stay in IIMA.</p>

<p style="text-align:justify;"><i class="fa fa-check"></i> A Grand Heritage Rally in IIM Campus as a tribute to Dr. APJ Abdul Kalam with  Yaaniks performing street plays, classical dance forms, festoons, play cards displaying the message of Indian Glory and spirit in the lines and dreams of Dr.Kalam. The Heritage Rally is done in association with UN Youth with the Theme Youth for Civic Engagement.</p>

<p style="text-align:justify;"><i class="fa fa-check"></i><b> Human Development Index Survey :</b>  Surveying of Native Villages of Gujarat on UNO’s Human Development Index surveying habits, habitat, life style, etiquettes ,ethos .ethics & Economics experiencing the  rural Gujarat. HDI Survey is done in association with UN YOUTH promoting Youth for Civic Engagement. The survey reports of the same shall be sent to UN DSDO and Prime Minister Office, New Delhi.</p>

<p style="text-align:justify;"><i class="fa fa-check"></i><b> The Great Indian Dancing Festival :</b> Documenting and preparing a Documentary on the age old art and artisans of Kathakali, Kuchipudi, Bharatanatyam, Mohiniattam . Surveying the life of Kathakali dancers and the love they had towards Kathakali dance. As a Cross Culture Initiative BharathaNatyam dancers, Kuchipudi dancers and Kathakali dancers shall dance for the same dance drama at a time helping the Yaaniks  & IIM Ahmedabad students to visualize their two eyes with three great Indian classical forms finding very tough to judge among  the three. Kathakali Festival is done in association with  Indian National Trust for Arts Culture and Heritage[INTACH].</p> 

<p style="text-align:justify;"><i class="fa fa-check"></i><b> Crafting Gujarat : </b> Studying the age old traditional handicrafts and arts of Gujarat and enterprising them on a global note. Case studying, Learning and interacting with the craftsman and artisans to know their creative pursuits in making such beautiful handicrafts, means of marketing their matchless work, support they receive from Governments Enterprises and NGO’s on economical frontiers.</p>

<p style="text-align:justify;"><i class="fa fa-check"></i><b> Grand Puppetry Festival : </b>Organising Puppetry shows with famous & ancient Puppetry artists of AndhraPradesh, Telangana & TamilNadu helping the students to visualize the Grand Ancient Indian Art & its greatness. Through Puppetry Festival & Puppet shows we shall  help the budding creative leaders to form an enticing bond, appreciation & affection towards Indian Art & Artists for whom Art is not just pArt but heArt of their life.</p>

<p style="text-align:justify;"><i class="fa fa-check"></i><b> Ecology  @ India’s Own Country :</b>  Experiencing the Ecology and environment of Gujarat state by a visit to native Gujarat villages with Yaaniks dressing themselves up with various props, facepaints displaying street plays related to the themes in teams of 20 members such as Save Birds, Save Live stock, Save Environment promoting the protection of Environment . It is done in association with Youth Hostels International  and NYC, Ministry of Youth Affairs.</p>
</ul>
<p style="text-align:justify;">All the Yaaniks are reviewed and evaluated on their participation in various events by the mentors allocated to them . The Participant shall be awarded a Yaan Knowledge Quotient [YKQ] in terms of CGPA assessing his inquiry, initiative, innovative, crisis management, behavioral, operational, teamwork, team building, creative, leadership capabilities, skills and traits through YAANIK EXECELLENCY EVALUATION SHEET [YEES].</p>
<div class="under-h2">09951090114[ Y.Bhargav]
	
<br>
 bhargav44@gmail.com
 <br> www.fb.com/JIGNASA
  </div>
       




</p>
				</div>
				
				
			</div>
		</div>
		<!-- End About Main Section -->
		
		
		
	
		
	
		
	
	<!-- Jquery Libs -->
	<!-- Latest Version Of Jquery -->
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<!-- Bootstrap.js -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!-- Sticky PLugin -->
	<script src="js/jquery.sticky.js"></script>
	<!-- Cube Portfolio -->
	<script type="text/javascript" src="js/jquery.cubeportfolio.min.js"></script>
	<script type="text/javascript" src="js/cbp-1.js"></script>
	<!-- Owl Carousel -->
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<!-- Wow Plugin -->
	<script type="text/javascript" src="js/wow.min.js"></script>
	<!--Easing animations Plugin -->
	<script type="text/javascript" src="js/easing.js"></script>
	<!--To-Top Button Plugin -->
    <script type="text/javascript" src="js/jquery.ui.totop.js"></script>
	<!-- SmoothScroll Plugin -->
	<script type="text/javascript" src="js/SmoothScroll.js"></script>
	<script type="text/javascript" src="js/modernizr-latest.js"></script>
	<script type="text/javascript" src="js/classie.js"></script>
	<script type="text/javascript" src="js/uisearch.js"></script>
	<script type="text/javascript" src="js/waypoints.min.js"></script>
	<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
	<!-- Theme Custom -->
	<script type="text/javascript" src="js/preloaders.js"></script>
	<script type="text/javascript" src="js/custom.js"></script>
	
	<!-- End Jquery Libs -->
	
	<script>
		jQuery().UItoTop({ easingType: 'easeOutQuart' });
	</script>

	</body>
	
<!-- Mirrored from gj-designs.in/universal/about.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:52:42 GMT -->
</html>
