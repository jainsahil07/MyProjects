<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
	
	
<!-- Mirrored from gj-designs.in/universal/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:45:12 GMT -->
<head>
	    <!-- Your Basic Site Informations -->
		<title>Jignasa Yaan-17</title>
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- Stylesheets -->
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.theme.css" />
		<link rel="stylesheet" type="text/css" href="css/cubeportfolio.css">
		
		<!-- REVOLUTION BANNER CSS SETTINGS -->
		<link rel="stylesheet" type="text/css" href="rs-plugin/css/settings.css" media="screen" />
		
		<!-- Google fonts -->
		<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
		
		<!-- Font Awesome -->
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css" />
		<style type="text/css">
			.whyuni {
    padding-top: 20px !important;
    padding-bottom: 10px !important;
    
}
		</style>
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		
		<!--[if lt IE 9]>
			<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->
		
	</head>
	<body>
		<!-- PRELOADER -->
		<div id="preloader">
			<div class="preloader-container">
				<h2>Loading</h2>
				<div class="card">
					<div class="loader">
						<div class="spin"></div>
						<div class="bounce"></div>
					</div>
				</div>
				<img style="margin-top:-12px;"  src="images/logo.png" class="l-logo" alt="" />
			</div>
		</div>
		<!-- END PRELOADER -->
		
		<!--Home-->
		<header>
			<div class="nav-wrap">
				
			
				
				
				<nav class="navbar navbar-default">
					<div class="container container-fluid">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="index.php"><img style="margin-top:-12px;" src="images/logo.png" alt="" /> </a>
						</div>
						
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<li>
									<a href="index.php" class="active">Home</a>
									<ul class="for-mob-menu">
										<li><a href="index.php" class="active">Home</a></li>
									</ul>
								</li>
								
								
								
								<li>
									<a href="about.php" >About Us</a>
									<ul class="for-mob-menu">
										<li><a href="about.php">About Us</a></li>
									</ul>
								</li>
								<li>
									<a href="aboutjy17.php" >About JY17</a>
									<ul class="for-mob-menu">
										<li><a href="aboutjy17.php">About Us</a></li>
									</ul>
								</li>
								
								
								<li>
									<a href="rulesandregulations.php">Rules and Regulations <span class="caret"></span></a>
									
									
								</li>
								
								
								
								
								
								
								<li>
									<a href="register.php" >Register</a>
									<ul class="for-mob-menu">
										<li><a href="register.php">Register</a></li>
									</ul>
								</li>
								<li>
									<a href="contact.php" >Contact</a>
									<ul class="for-mob-menu">
										<li><a href="contact.php">Contact</a></li>
									</ul>
								</li>
								
							</ul>
							
							
							
						</div><!-- /.navbar-collapse -->
						
						
					</div><!-- /.container-fluid -->
				</nav>
				
			</div>
			
		</header>
		
		<!-- Big Banner -->
		<div class="tp-banner-container">
			<div class="tp-banner" >
				<ul>
					
					<li data-transition="fade" data-slotamount="7" data-masterspeed="1300">
						<img src="images/s2.jpg" alt="" >	
						
						<div class="tp-caption large_bold_white customin customout"
						data-x="10"
						data-y="235"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="1400"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						>EK BHARATH
						</div>
						
						<div class="tp-caption large_bold_white customin customout"
						data-x="10"
						data-y="295"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="1400"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						> SHRESTA  BHARAT
						</div>
						
						<div class="tp-caption customin customout"
						data-x="15"
						data-y="400"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="1800"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						>
						</div>
						
						<div class="tp-caption banner-p-2 customin customout "
						data-x="15"
						data-y="460"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="2000"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						><p style="color:white;"><b>Be the Part of Asia's Largest Education on Wheels for Arts, Culture & Heritage.....JIGNASA YAAN 17<br>Motto: Spreading the Spirit of Unity as Proud Indians<br>Experience the Enticing BOND with Enchanting LAND….GUJARAT</b></p>
							
						</div>
						
						<div class="tp-caption customin customout "
						data-x="15"
						data-y="580"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="2200"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						><a href="register.php" class="tour">REGISTER HERE</a>
						</div>
						
						
					</li>
					
					
					<li data-transition="fade" data-slotamount="7" data-masterspeed="1300">
						<img src="images/s3.jpg" alt="" data-bgposition="left center" data-kenburns="on" data-duration="14000" data-ease="Linear.easeNone" data-bgfit="100" data-bgfitend="130" data-bgpositionend="center center" >	
						
						<div class="tp-caption logo3 customin customout"
						data-x="440"
						data-y="130"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="1400"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						>
						</div>
						
						<div class="tp-caption logo3 customin customout"
						data-x="700"
						data-y="325"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="1400"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						>
						</div>
						
						
						
						<div class="tp-caption customin customout"
						data-x="15"
						data-y="240"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="1400"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						><h2>JIGNASA JY17</h2>
						</div>
						
						<div class="tp-caption customin customout"
						data-x="15"
						data-y="355"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="1800"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						><h3><span class="color-b"> Bigger This Time</span></h3>
						</div>
						
						<div class="tp-caption banner-p-1 customin customout "
						data-x="15"
						data-y="415"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="2000"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						>
							
						</div>
						
						<div class="tp-caption customin customout "
						data-x="15"
						data-y="560"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="2200"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						>
						</div>
						<li data-transition="fade" data-slotamount="7" data-masterspeed="1300">
						<img src="images/s6.jpg" alt="" data-bgposition="left center" data-kenburns="on" data-duration="14000" data-ease="Linear.easeNone" data-bgfit="100" data-bgfitend="130" data-bgpositionend="center center" >	
						
						<div class="tp-caption logo3 customin customout"
						data-x="440"
						data-y="130"
						
						data-customin="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						data-customout="x:-300;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:1;scaleY:1;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
						
						data-start="1400"
						data-speed="600"
						data-easing="Power2.easeIn"
						
						data-endspeed="600"
						data-endeasing="Linear.easeNone"
						>
						</div>
					</li>


						
					</li>
				</ul>
			</div>
		</div>
		<div class="whyuni">
			<div class="container">
				
				<div class="col-md-12">
					
					
					
					  <div class="panel panel-default">
						<div class="panel-heading" role="tab">
						  <h4 class="panel-title">
						  Know About Jignasa
						  </h4>
						</div>
						<div role="tabpanel">
						  <div class="panel-body">
							<p>Jignasa is all set once again for a splendid sojourn of Knowledge-JIGNASA YAAN 2015- on the path of Creative Leadership.<p>
<p>Hope on with hunger for skills, and satiate your thirst for travel with this exquisitely happening EduTage journey to Dhanak- an annual extravaganza of Indian Institute of Space Technology, Trivandrum from October 16th to October 20th 2015.</p>
<p>Accomplish the dream of the visionary crusader-A.P.J. Abdul Kalam, who taught India how to dream in the ‘God’s own Country’ at times like this when the ‘odds shone in bounty’. Get on board this spaceship of JIGNASA YAAN to levitate beyond borders of inertia and push your limits beyond the stars, for, excellence lies at the pinnacle of your endeavours.</p> 
<p><b>In a nutshell-</b>
<ul>
<p><i class="fa fa-check"> Bring up the energy in you,</i></p>
<p><i class="fa fa-check"> Enthuse and enlighten the spirit that’s blue,</i></p>
<p><i class="fa fa-check"> Out there the world is new,</i></p>
<p><i class="fa fa-check"> Time & effort is the only due.</i></p>

</ul>
</p>
						  </div>
						</div>
					  </div>
					 
					 
					  
					 
					
				</div>
				
				
				
			</div>
		</div>
		

		
		
	
		
		
		
		
	
		
		
	
		
	
		
		
		
		
		
		
		<!-- Jquery Libs -->
		<!-- Latest Version Of Jquery -->
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<!-- Bootstrap.js -->
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<!-- Sticky PLugin -->
		<script src="js/jquery.sticky.js"></script>
		<!-- jQuery REVOLUTION Slider  -->
		<script type="text/javascript" src="rs-plugin/js/jquery.themepunch.tools.min.js"></script>
		<script type="text/javascript" src="rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
		<!-- Owl Carousel -->
		<script type="text/javascript" src="js/owl.carousel.min.js"></script>
		<!-- Wow Plugin -->
		<script type="text/javascript" src="js/wow.min.js"></script>
		<!--Easing animations Plugin -->
		<script type="text/javascript" src="js/easing.js"></script>
		<!--To-Top Button Plugin -->
		<script type="text/javascript" src="js/jquery.ui.totop.js"></script>
		<!-- SmoothScroll Plugin -->
		<script type="text/javascript" src="js/SmoothScroll.js"></script>
		<script type="text/javascript" src="js/modernizr-latest.js"></script>
		<script type="text/javascript" src="js/classie.js"></script>
		<script type="text/javascript" src="js/uisearch.js"></script>
		<script type="text/javascript" src="js/waypoints.min.js"></script>
		<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
		<!-- Cube Portfolio -->
		<script type="text/javascript" src="js/jquery.cubeportfolio.min.js"></script>
		<script type="text/javascript" src="js/cbp-1.js"></script>
		<!-- bxSlider Javascript file -->
		<script type="text/javascript" src="js/jquery.bxslider.min.js"></script>
		<!-- Theme Custom -->
		<script type="text/javascript" src="js/preloaders.js"></script>
		<script type="text/javascript" src="js/slider.js"></script>
		<script type="text/javascript" src="js/custom.js"></script>
		<!-- End Jquery Libs -->
		
	</body>

<!-- Mirrored from gj-designs.in/universal/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:47:53 GMT -->
</html>
