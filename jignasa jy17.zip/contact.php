<?php 
if($_SERVER['REQUEST_METHOD']=='POST')
{
$host="localhost"; // Host name 
$username="codinggu_jignasa"; // Mysql username 
$password="R^SqhOJ#7%Xt"; // Mysql password 
$db_name="codinggu_jignasa"; // Database name 
$tbl_name="contact"; // Table name 
// Connecting to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
$name=htmlspecialchars($_POST['name'],ENT_QUOTES);
$email=htmlspecialchars($_POST['email'],ENT_QUOTES);
$subject=htmlspecialchars($_POST['subject'],ENT_QUOTES);
$message=htmlspecialchars($_POST['message'],ENT_QUOTES);

$sql="INSERT INTO $tbl_name(name, email, subject, message)VALUES('$name', '$email', '$subject', '$message')";
$result=mysql_query($sql); 
if($result){
echo "<script>alert('We will contact you soon.');</script>";
}
else {
echo "<script>alert('Error occurred please try again.');</script>";
}
mysql_close();
}

 ?>

 <!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

	
<!-- Mirrored from gj-designs.in/universal/contact.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:53:14 GMT -->
<head>
	    <!-- Your Basic Site Informations -->
		<title>Jignasa Yaan-17</title>
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- Stylesheets -->
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.theme.css" />
		<link rel="stylesheet" type="text/css" href="css/cubeportfolio.css">

		<!-- REVOLUTION BANNER CSS SETTINGS -->
		<link rel="stylesheet" type="text/css" href="rs-plugin/css/settings.css" media="screen" />

		<!-- Google fonts -->
		<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
		
		<!-- Font Awesome -->
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css" />

		<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->
		<script type="text/javascript">
				function ajax()
				{
				var a=document.getElementById('contact_name').value;
				var b=document.getElementById('contact_email').value;
				var c=document.getElementById('contact_subject').value;
				var e=document.getElementById('contact_message').value;



				var x;
				if(window.XMLHttpRequest)
				{
				x=new XMLHttpRequest();
				}
				else
				{
				x=new ActiveXObject("Microsoft.XMLHTTP");
				}

				x.open("GET.php","contact49de.php?name="+a+"& email="+b+"& subject="+c+"& message="+e,true);

				x.send();

				x.onreadystatechange=function()
				{
				if(x.readyState==4 && x.status==200)
				{
				document.getElementById("p1").innerHTML=x.responseText;
				}
				}
				}

		</script>
		
	</head>
	<body>
	
		<!--Header-->
		<header>
			<div class="header2">
		
			
		<!--End Home-->
		
		
				
				<nav class="navbar navbar-default">
					<div class="container container-fluid">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="index.php"><img style="margin-top:-12px;" src="images/logo.png" alt="" /> </a>
						</div>
						
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<li>
									<a href="index.php">Home</a>
									<ul class="for-mob-menu">
										<li><a href="index.php" class="active">Home</a></li>
									</ul>
								</li>
								
								
								
								<li>
									<a href="about.php" >About Us</a>
									<ul class="for-mob-menu">
										<li><a href="about.php">About Us</a></li>
									</ul>
								</li>
								<li>
									<a href="aboutjy17.php" >About JY17</a>
									<ul class="for-mob-menu">
										<li><a href="aboutjy17.php">About Us</a></li>
									</ul>
								</li>
								
								
								<li>
									<a href="rulesandregulations.php">Rules and Regulations <span class="caret"></span></a>
									
									
								</li>
								
								
								
								
								
								
								<li>
									<a href="register.php" >Register</a>
									<ul class="for-mob-menu">
										<li><a href="register.php">Register</a></li>
									</ul>
								</li>
								<li>
									<a href="contact.php" class="active" >Contact</a>
									<ul class="for-mob-menu">
										<li><a href="contact.php">Contact</a></li>
									</ul>
								</li>
								
							</ul>
							
							
							
						</div><!-- /.navbar-collapse -->
						
						
					</div><!-- /.container-fluid -->
				</nav>
		
	
		
		</div>
		
		</header>
		<!-- End Header Section -->
		
		<!-- Start Contact Main Section -->
		<div class="contact">
			<div class="container">
				
			
				<div class="contact-form-wrap">
					
					
					<div class="col-md-10 right">
						<h3>Get In Touch With Us</h3>
						<form id="contact-form" action="contact.php" method="post">
						    <input type="text" name="name" id="contact_name" required placeholder="Name" class="required" title="Your Name" />
							<input type="email" name="email" id="contact_email" required  placeholder="Email" class="last-item required" title="Your Email" />
							<input type="text" name="subject" id="contact_subject" required placeholder="Subject" class="last-item required" title="Subject" />               
							<div class="clear"></div>
							<textarea name="message" id="contact_message" required placeholder="Type your questions here..." class="required textarea" ></textarea>
							<input type="submit" class="submit no-margin-bottom"  value="Send Message"/>
							<p id="p1"></p>
							<span></span>
					</form>
						
					</div>
				</div>
			
			</div>
		</div>
		<!-- End Contact Main Section -->
		
		
	
		
		
		
		
		
	
	<!-- Jquery Libs -->
	<!-- Latest Version Of Jquery -->
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<!-- Bootstrap.js -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!-- Sticky PLugin -->
	<script src="js/jquery.sticky.js"></script>
	<!-- Cube Portfolio -->
	<script type="text/javascript" src="js/jquery.cubeportfolio.min.js"></script>
	<script type="text/javascript" src="js/cbp-1.js"></script>
	<!-- Owl Carousel -->
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<!-- Wow Plugin -->
	<script type="text/javascript" src="js/wow.min.js"></script>
	<!--Easing animations Plugin -->
	<script type="text/javascript" src="js/easing.js"></script>
	<!--To-Top Button Plugin -->
    <script type="text/javascript" src="js/jquery.ui.totop.js"></script>
	<!-- Google Maps -->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
	<script type="text/javascript" src="js/map.js"></script>
	<!-- SmoothScroll Plugin -->
	<script type="text/javascript" src="js/SmoothScroll.js"></script>
	<script type="text/javascript" src="js/modernizr-latest.js"></script>
	<script type="text/javascript" src="js/classie.js"></script>
	<script type="text/javascript" src="js/uisearch.js"></script>
	<script type="text/javascript" src="js/waypoints.min.js"></script>
	<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
	<!-- Theme Custom -->
	<script type="text/javascript" src="js/preloaders.js"></script>
	<script type="text/javascript" src="js/custom.js"></script>
	
	<!-- End Jquery Libs -->
	
	<script>
		jQuery().UItoTop({ easingType: 'easeOutQuart' });
	</script>

	</body>
	
<!-- Mirrored from gj-designs.in/universal/contact.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:53:19 GMT -->
</html>
