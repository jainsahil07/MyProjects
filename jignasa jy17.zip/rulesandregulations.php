<!DOCTYPE html>

<head>
	    <!-- Your Basic Site Informations -->
		<title>Jignasa Yaan-17</title>
		
		<!-- Stylesheets -->
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.theme.css" />
		<link rel="stylesheet" type="text/css" href="css/cubeportfolio.css">

		<!-- REVOLUTION BANNER CSS SETTINGS -->
		<link rel="stylesheet" type="text/css" href="rs-plugin/css/settings.css" media="screen" />

		<!-- Google fonts -->
		<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
		
		<!-- Font Awesome -->
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css" />

		
		
	</head>
	<body>
	
		<!--Header-->
		<header>
			<div class="header2">
		
		
		
		
				
				<nav class="navbar navbar-default">
					<div class="container container-fluid">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="index.php"><img style="margin-top:-12px;" src="images/logo.png" alt="" /> </a>
						</div>
						
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<li>
									<a href="index.php">Home</a>
									<ul class="for-mob-menu">
										<li><a href="index.php" class="active">Home</a></li>
									</ul>
								</li>
								
								
								
								<li>
									<a href="about.php" >About Us</a>
									<ul class="for-mob-menu">
										<li><a href="about.php">About Us</a></li>
									</ul>
								</li>
								<li>
									<a href="aboutjy17.php" >About JY17</a>
									<ul class="for-mob-menu">
										<li><a href="aboutjy17.php">About Us</a></li>
									</ul>
								</li>
								
								
								<li>
									<a href="services.php" class="active">Rules and Regulations <span class="caret"></span></a>
									
									
								</li>
								
								
								
								
								
								
								<li>
									<a href="register.php" >Register</a>
									<ul class="for-mob-menu">
										<li><a href="register.php">Register</a></li>
									</ul>
								</li>
								<li>
									<a href="contact.php" >Contact</a>
									<ul class="for-mob-menu">
										<li><a href="contact.php">Contact</a></li>
									</ul>
								</li>
								
							</ul>
							
							
							
						</div><!-- /.navbar-collapse -->
						
						
					</div><!-- /.container-fluid -->
				</nav>
		
		</div>
		
		</header>
		<!-- End Header Section -->
		
	
		
	
		
	<div class="whyuni">
			<div class="container">
				
			
				<div class="col-md-12">
					
					
					<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					  <div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
						  <h4 class="panel-title">
							<a role="button" data-toggle="collapse" data-parent="#accordion" aria-expanded="true" aria-controls="collapseOne">
							  RULES AND REGULATIONS TO FOLLOW
							</a>
						  </h4>
						</div>
						<div class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
						  <div class="panel-body">
							<p class="fa fa-check">An Yatri cannot participate individually in the JIGNASA YATRA. He can participate only if He is from Participant College.</p>
<p class="fa fa-check"> A college can be a participant college when we invited it through an official invitation through the concerned faculty of student activities.</p>
<p class="fa fa-check"> We also have the Limit of students from the participant college based on their association with JIGNASA Foundation.</p>
<p class="fa fa-check"> The Participant College shall send a minimum of one Faculty Co ordinator to co ordinate the students of Participant college.</p>
<p class="fa fa-check"> With the support of the Faculty Coordinator, JIGNASA Foundation shall conduct selections for the interested students and select the student delegates for JIGNASA YATRA.</p>
<p class="fa fa-check"> The Selection process will be an interview, written test testing the Student Activity orientation, Leadership Skills, Team Building , Operational, Entrepreneurship Abilities of the Student.</p> 
<p class="fa fa-check"> The Selection process will be conducted in the participant college itself.</p>


						  </div>
						</div>
					  </div>
					 
					 
					  
					</div>
				</div>
				
				
				
			</div>
		</div>
		
		
	
		
		
		
		
	<!-- Jquery Libs -->
	<!-- Latest Version Of Jquery -->
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<!-- Bootstrap.js -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!-- Sticky PLugin -->
	<script src="js/jquery.sticky.js"></script>
	<!-- Cube Portfolio -->
	<script type="text/javascript" src="js/jquery.cubeportfolio.min.js"></script>
	<script type="text/javascript" src="js/cbp-1.js"></script>
	<!-- Owl Carousel -->
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<!-- Wow Plugin -->
	<script type="text/javascript" src="js/wow.min.js"></script>
	<!--Easing animations Plugin -->
	<script type="text/javascript" src="js/easing.js"></script>
	<!--To-Top Button Plugin -->
    <script type="text/javascript" src="js/jquery.ui.totop.js"></script>
	<!-- SmoothScroll Plugin -->
	<script type="text/javascript" src="js/SmoothScroll.js"></script>
	<script type="text/javascript" src="js/modernizr-latest.js"></script>
	<script type="text/javascript" src="js/classie.js"></script>
	<script type="text/javascript" src="js/uisearch.js"></script>
	<script type="text/javascript" src="js/waypoints.min.js"></script>
	<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
	<!-- Theme Custom -->
	<script type="text/javascript" src="js/preloaders.js"></script>
	<script type="text/javascript" src="js/custom.js"></script>
	
	<!-- End Jquery Libs -->
	
	<script>
		jQuery().UItoTop({ easingType: 'easeOutQuart' });
	</script>

	</body>
	
<!-- Mirrored from gj-designs.in/universal/services.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:51:56 GMT -->
</html>
