<?php 

if($_SERVER['REQUEST_METHOD']=='POST')
{
$host="localhost"; // Host name 
$username="codinggu_jignasa"; // Mysql username 
$password="R^SqhOJ#7%Xt"; // Mysql password 
$db_name="codinggu_jignasa"; // Database name 
$tbl_name="register"; // Table name 
// Connecting to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect"); 
mysql_select_db("$db_name")or die("cannot select DB");
$name=htmlspecialchars($_POST['name'],ENT_QUOTES);
$college_name=htmlspecialchars($_POST['clg_name'],ENT_QUOTES);
$specialization=htmlspecialchars($_POST['spec'],ENT_QUOTES);
$year=htmlspecialchars($_POST['year'],ENT_QUOTES);
$phone_number=htmlspecialchars($_POST['phno'],ENT_QUOTES);
$department=htmlspecialchars($_POST['dept'],ENT_QUOTES);
$email=htmlspecialchars($_POST['email'],ENT_QUOTES);
$sql="INSERT INTO $tbl_name(name, college_name, specialization, year, phone_number, email, department)VALUES('$name', '$college_name', '$specialization', '$year', '$phone_number', '$email', '$department')";
$result=mysql_query($sql); 
if($result){
echo "<script>alert('Registration successful. We will contact you soon.');</script>";
}
else {
echo "<script>alert('Error occurred please try again.');</script>";
}
mysql_close();
}

 ?>

 <!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

	
<!-- Mirrored from gj-designs.in/universal/contact.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:53:14 GMT -->
<head>
	    <!-- Your Basic Site Informations -->
		<title>Jignasa Yaan-17</title>
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- Stylesheets -->
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.theme.css" />
		<link rel="stylesheet" type="text/css" href="css/cubeportfolio.css">

		<!-- REVOLUTION BANNER CSS SETTINGS -->
		<link rel="stylesheet" type="text/css" href="rs-plugin/css/settings.css" media="screen" />

		<!-- Google fonts -->
		<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
		
		<!-- Font Awesome -->
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css" />

		<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->
		<script type="text/javascript">
				function ajax()
				{
				var a=document.getElementById('contact_name').value;
				var b=document.getElementById('contact_email').value;
				var c=document.getElementById('contact_subject').value;
				var e=document.getElementById('contact_message').value;



				var x;
				if(window.XMLHttpRequest)
				{
				x=new XMLHttpRequest();
				}
				else
				{
				x=new ActiveXObject("Microsoft.XMLHTTP");
				}

				x.open("GET.php","contact49de.php?name="+a+"& email="+b+"& subject="+c+"& message="+e,true);

				x.send();

				x.onreadystatechange=function()
				{
				if(x.readyState==4 && x.status==200)
				{
				document.getElementById("p1").innerHTML=x.responseText;
				}
				}
				}

		</script>
		
	</head>
	<body>
	
		<!--Header-->
		<header>
			<div class="header2">
		
			
		<!--End Home-->
		
		
				
				<nav class="navbar navbar-default">
					<div class="container container-fluid">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="index.php"><img style="margin-top:-12px;" src="images/logo.png" alt="" /> </a>
						</div>
						
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<li>
									<a href="index.php">Home</a>
									<ul class="for-mob-menu">
										<li><a href="index.php" class="active">Home</a></li>
									</ul>
								</li>
								
								
								
								<li>
									<a href="about.php" >About Us</a>
									<ul class="for-mob-menu">
										<li><a href="about.php">About Us</a></li>
									</ul>
								</li>
								<li>
									<a href="aboutjy17.php" >About JY17</a>
									<ul class="for-mob-menu">
										<li><a href="aboutjy17.php">About Us</a></li>
									</ul>
								</li>
								
								
								<li>
									<a href="rulesandregulations.php">Rules and Regulations <span class="caret"></span></a>
									
									
								</li>
								
								
								
								
								
								
								<li>
									<a href="register.php" class="active">Register</a>
									<ul class="for-mob-menu">
										<li><a href="register.php">Register</a></li>
									</ul>
								</li>
								<li>
									<a href="contact.php" >Contact</a>
									<ul class="for-mob-menu">
										<li><a href="contact.php">Contact</a></li>
									</ul>
								</li>
								
							</ul>
							
							
							
						</div><!-- /.navbar-collapse -->
						
						
					</div><!-- /.container-fluid -->
				</nav>
	
		
		</div>
		
		</header>
		<!-- End Header Section -->
		
		<!-- Start Contact Main Section -->
		<div class="contact">
			<div class="container">
				
			
				<div class="contact-form-wrap">
					<div class="col-md-4 left">
					 <h5>Registration Tab Details</h5>
					  <p style="text-align: justify">To be part of  India's Largest Education on Wheels JIGNASA YAAN 17  as YAANIK..  takes 5 simple steps</p>
						<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					  <div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
						  <h4 class="panel-title">
							<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
							  STEP-1
							</a>
						  </h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
						  <div class="panel-body">
						<p>Register yourself in the website providing your basic details in the Register Tab below.</p>
						  </div>
						</div>
					  </div>
					  <div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
						  <h4 class="panel-title">
							<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
							  STEP-2
							</a>
						  </h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
						  <div class="panel-body">
							<p style="text-align:justify;">On Completion of Registration you shall receive a phone call to the phone number you have provided in the Registration for a Telephonic Interview with in 24 hours probably in working hours[8am - 8pm].</p>
						  </div>
						</div>
					  </div>
					  <div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
						  <h4 class="panel-title">
							<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
							  STEP-3
							</a>
						  </h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
						  <div class="panel-body">
							<p style="text-align:justify;">You shall receive a mail of confirmation & information to the registered mail informing you the further  procedure,if you are selected for the JIGNASA YAAN 15 as Yaanik.</p>
						  </div>
						</div>
					  </div>
					  
					   <div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingFour">
						  <h4 class="panel-title">
							<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
							  STEP-4
							</a>
						  </h4>
						</div>
						<div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
						  <div class="panel-body">
							<p style="text-align:justify;">On receiving Confirmation mail as Yaanik, You shall fill the details in the forms sent in your confirmation mail and mail the filled form to <b><a href="mailto:yaan@jignasa.org">yaan@jignasa.org</a></b> and make the payment as informed in the confirmation mail</p>
						  </div>
						</div>

					  </div>
					   <div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingFive">
						  <h4 class="panel-title">
							<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
							  STEP-5
							</a>
						  </h4>
						</div>
						<div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive">
						  <div class="panel-body">
							<p style="text-align:justify;">You shall receive your confirmed enrollment as YAANIK [PARTICIPANT] of JIGNASA YAAN 15 with attested ID Card & Contact details for further correspondence.</p>
						  </div>
						</div>
					  </div>
					  <h6 style="text-align: justify;"><b>What are waiting for book your space in this space journey of skills by clicking the button below to Register</b></h6>
					</div>
					</div>
					
					<div class="col-md-8 right">
						<h3>Get In Touch With Us</h3>
						<form id="contact-form" action="register.php" method="post">
						    <input type="text" name="name" id="contact_name" required placeholder="Name" class="required" title="Your Name" />
						     <input type="text" name="clg_name" id="contact_name" required placeholder="College Name" class="required" title="Your Name" />
						       <input type="text" name="spec" id="contact_name" required placeholder="Specialization" class="required" title="Your Name" />
							<input type="email" name="year" id="contact_email" required  placeholder="Year" class="last-item required" title="Your Email" />
							  <input type="text" name="phno" id="contact_name" required placeholder="Phone no" class="required" title="Your Name" />
							    <input type="text" name="email" id="contact_name" required placeholder="Email" class="required" title="Your Name" />
							      <input type="text" name="dept" id="contact_name" required placeholder="department" class="required" title="Your Name" />
							              
							
							<input type="submit" class="submit no-margin-bottom"  value="Register" />
							<p id="p1"></p>
							<span></span>
					</form>
						
					</div>
				</div>
			
			</div>
		</div>
		<!-- End Contact Main Section -->
		
		
	
		
		
		
		
		
	
	<!-- Jquery Libs -->
	<!-- Latest Version Of Jquery -->
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<!-- Bootstrap.js -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!-- Sticky PLugin -->
	<script src="js/jquery.sticky.js"></script>
	<!-- Cube Portfolio -->
	<script type="text/javascript" src="js/jquery.cubeportfolio.min.js"></script>
	<script type="text/javascript" src="js/cbp-1.js"></script>
	<!-- Owl Carousel -->
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<!-- Wow Plugin -->
	<script type="text/javascript" src="js/wow.min.js"></script>
	<!--Easing animations Plugin -->
	<script type="text/javascript" src="js/easing.js"></script>
	<!--To-Top Button Plugin -->
    <script type="text/javascript" src="js/jquery.ui.totop.js"></script>
	<!-- Google Maps -->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
	<script type="text/javascript" src="js/map.js"></script>
	<!-- SmoothScroll Plugin -->
	<script type="text/javascript" src="js/SmoothScroll.js"></script>
	<script type="text/javascript" src="js/modernizr-latest.js"></script>
	<script type="text/javascript" src="js/classie.js"></script>
	<script type="text/javascript" src="js/uisearch.js"></script>
	<script type="text/javascript" src="js/waypoints.min.js"></script>
	<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
	<!-- Theme Custom -->
	<script type="text/javascript" src="js/preloaders.js"></script>
	<script type="text/javascript" src="js/custom.js"></script>
	
	<!-- End Jquery Libs -->
	
	<script>
		jQuery().UItoTop({ easingType: 'easeOutQuart' });
	</script>

	</body>
	
<!-- Mirrored from gj-designs.in/universal/contact.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:53:19 GMT -->
</html>
