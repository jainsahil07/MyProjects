<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

	
<!-- Mirrored from gj-designs.in/universal/about.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:52:30 GMT -->
<head>
	    <!-- Your Basic Site Informations -->
		<title>Jignasa Yaan-17</title>
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- Stylesheets -->
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.theme.css" />
		<link rel="stylesheet" type="text/css" href="css/cubeportfolio.css">

		<!-- REVOLUTION BANNER CSS SETTINGS -->
		<link rel="stylesheet" type="text/css" href="rs-plugin/css/settings.css" media="screen" />

		<!-- Google fonts -->
		<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
		
		<!-- Font Awesome -->
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css" />

		<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->
		
	</head>
	<body>
	
		<!--Header-->
		<header>
			<div class="header2">
		
			
		
		
				
				<nav class="navbar navbar-default">
					<div class="container container-fluid">
						<!-- Brand and toggle get grouped for better mobile display -->
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
							<a class="navbar-brand" href="index.php"><img style="margin-top:-12px;" src="images/logo.png" alt="" /> </a>
						</div>
						
						<!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
							<ul class="nav navbar-nav navbar-right">
								<li>
									<a href="index.php">Home</a>
									<ul class="for-mob-menu">
										<li><a href="index.php" class="active">Home</a></li>
									</ul>
								</li>
								
								
								
								<li>
									<a href="about.php" class="active" >About Us</a>
									<ul class="for-mob-menu">
										<li><a href="about.php">About Us</a></li>
									</ul>
								</li>
								<li>
									<a href="aboutjy17.php" >About JY17</a>
									<ul class="for-mob-menu">
										<li><a href="aboutjy17.php">About Us</a></li>
									</ul>
								</li>
								
								
								<li>
									<a href="rulesandregulations.php">Rules and Regulations <span class="caret"></span></a>
									
									
								</li>
								
								
								
								
								
								
								<li>
									<a href="register.php" >Register</a>
									<ul class="for-mob-menu">
										<li><a href="register.php">Register</a></li>
									</ul>
								</li>
								<li>
									<a href="contact.php" >Contact</a>
									<ul class="for-mob-menu">
										<li><a href="contact.php">Contact</a></li>
									</ul>
								</li>
								
							</ul>
							
							
							
						</div><!-- /.navbar-collapse -->
						
						
					</div><!-- /.container-fluid -->
				</nav>
		
		
		
		</div>
		
		</header>
		<!-- End Header Section -->
		
		<!-- Start About Main Section -->
		<div class="about-main">
			<div class="container">
				<div class="col-md-12">
					<h2>ABOUT <span>US</span></h2>
					<div class="under-h2">OUR MISSION IS TO PROVIDE BEST QUALITY WORK.</div>
					<p style="text-align:justify;">We are promoting Creative Leadership through Education Theme as a Tribute to Hon’ble Former President of India BharathRatna Dr.APJ Abdul Kalam . Dr.Kalam from the past 5 years is meticulously working on Creative Leadership through Education and He had delievered various addresses at IIT’s , IIM’s and elite institutions of the country and world on the above said Theme to direct the Indian Youth towards Creative Leadership. Prime Minister Shri Narendra Modi said that it was His big dream to see all our Educational institutions, Education initiatives and curriculum are directed promoting the message of EK BHARATH SHRESTA BHARATH as a Tribute to Iron Man of India Shri Sardar Vallabhbhai Patel. In our mission to associate with such noble visionary and noble mission, JIGNASA in its annual Edutage Journey JIGNASA YAAN had taken up Theme : Ek BHARATH SHREST BHARATH-Exposure to Diversified Cultures- Essential For Creative Leaders. Through this humble Entrepreneural attempt of us, we want to add a little drop to the oceanic visionary mission of Shri Narendra Modi.</p>
					<p style="text-align:justify;">JIGNASA YAAN 16 with the above said Theme is a Knowledge Journey to Indian Institute of Technology, BHU Annual Festival Kashiyatra 2016. IIT BHU is the brain child of Bharath Ratna MadanaMohana Malavya. JIGNASA YAAN’16 is planned from February17th to February 21st ,2016 to IIT Campus.</p>
					<p style="text-align:justify;">JIGNASA YAAN 16 had plethora of Creative and Innovative Events on train and in the IISTcampus. 5 Advisors and 40 Mentors from Corporate Field and from Elite institutions who held various roles such as Entrepreneurs, HR Managers, Developers, Project Managers, Technical Leads, Resource persons who had elite innovative creative backgrounds are joining the students on the Train to guide them in the aspects of Innovation, Creativity, Career and Leadership. Every 12 students shall be guided by a Mentor.</p>
					<p style="text-align:justify;">Kashiyatra’16 is one of the Asia's prominent festivals attracting the crowds from Southern India, Eastern India and Northern India. Kashyatra 16 displays the rich creative pursuits of India as many eminent leaders had taken active role in designing the curriculum. A student can experience rich Indian Nativity and culture through various events in Kashiyatra 16. With such experience, the student shall envision his future goal as Creative Leader by learning to work effectively by mingling with people from Diversified Cultures.</p>
					<p style="text-align:justify;">JIGNASA has already conducted Heritage tours to IIT MADRAS in January,2014 with 120 students , to BITS Pilani, Pilani[Rajasthan] in October,2014 with 160 students and to IIT BHU, Varanasi in February 2015 with 60 students from AndhraPradesh. In 2015 with 436 students to IIST Trivandrum. We have promoted the UNESCO Theme in the IIT Madras Campus , BITS Pilani,IIT BHU, IIST campus through Heritage Rallys. JIGNASA Foundation takes pride in being the first organisation in the history of IITM , BITS, IIST to utilize the campus of IIT MADRAS , BITS PILANI, INDIAN INSTITUTE OF SPACE TECHNOLOGY to organize student rallies promoting Theme .</p>
					<p style="text-align:justify;">We have also initiated cross culture student interactions with active student representatives of IIT MADRAS Student Gymkhana, BITS Students Union, NIRAMAAN Social Service Unit of BITS Pilani, Entrepreneurship and Incubation cell, IIT BHU ,IIST SAC with the student delegates from the participant colleges of AndhraPradesh. KLUniversity, Vignan University,VRSiddhartha, PVP Siddhartha,SRKIT, Vignan’s LARA, VVIT are the participant colleges of these Edutage tours. By these vision filled attempts of the participants of Knowledge Journey, JIGNASA is very much satisfied to witness the grown and ever growing Creative Leaders of our nation impacting Global change with little initiative triggering from us.</p>
					<p style="text-align:justify;">The student representatives had improvised their innate talents and student activity orientation participating in these trips. The student participants of these had developed a sense of ownership and increased affinity towards their college and student activities. With this vision blended with affinity towards their institute they had initiated and developed various student activity initiatives, student activity centres in their respective college with their creative pursuits and knowledge they had acquired by witnessing the broad world through the knowledge journeys.</p>
				</div>
				
				
			</div>
		</div>
		<!-- End About Main Section -->
		
		
		
	
		
	
		
	
	<!-- Jquery Libs -->
	<!-- Latest Version Of Jquery -->
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<!-- Bootstrap.js -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!-- Sticky PLugin -->
	<script src="js/jquery.sticky.js"></script>
	<!-- Cube Portfolio -->
	<script type="text/javascript" src="js/jquery.cubeportfolio.min.js"></script>
	<script type="text/javascript" src="js/cbp-1.js"></script>
	<!-- Owl Carousel -->
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<!-- Wow Plugin -->
	<script type="text/javascript" src="js/wow.min.js"></script>
	<!--Easing animations Plugin -->
	<script type="text/javascript" src="js/easing.js"></script>
	<!--To-Top Button Plugin -->
    <script type="text/javascript" src="js/jquery.ui.totop.js"></script>
	<!-- SmoothScroll Plugin -->
	<script type="text/javascript" src="js/SmoothScroll.js"></script>
	<script type="text/javascript" src="js/modernizr-latest.js"></script>
	<script type="text/javascript" src="js/classie.js"></script>
	<script type="text/javascript" src="js/uisearch.js"></script>
	<script type="text/javascript" src="js/waypoints.min.js"></script>
	<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
	<!-- Theme Custom -->
	<script type="text/javascript" src="js/preloaders.js"></script>
	<script type="text/javascript" src="js/custom.js"></script>
	
	<!-- End Jquery Libs -->
	
	<script>
		jQuery().UItoTop({ easingType: 'easeOutQuart' });
	</script>

	</body>
	
<!-- Mirrored from gj-designs.in/universal/about.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:52:42 GMT -->
</html>
