<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->

	
<!-- Mirrored from gj-designs.in/universal/services-2.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:52:09 GMT -->
<head>
	    <!-- Your Basic Site Informations -->
		<title>Universal - Colorful Template</title>
		<meta http-equiv="content-type" content="text/html;charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- Stylesheets -->
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
		<link rel="stylesheet" type="text/css" href="css/owl.theme.css" />
		<link rel="stylesheet" type="text/css" href="css/cubeportfolio.css">

		<!-- REVOLUTION BANNER CSS SETTINGS -->
		<link rel="stylesheet" type="text/css" href="rs-plugin/css/settings.css" media="screen" />

		<!-- Google fonts -->
		<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
		<link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
		
		<!-- Font Awesome -->
		<link rel="stylesheet" type="text/css" href="fonts/font-awesome/css/font-awesome.min.css" />

		<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->
		
	</head>
	<body>
	
		<!--Header-->
		<header>
			<div class="header2">
		
			<div class="top-bar">
				<div class="container">
					<div class="col-md-6 top-info">
						<i class="fa fa-envelope"></i>
						<span class="top-bar-text">mail@gj-designs.in</span>
						
						<i class="fa fa-mobile fa-lg"></i>
						<span class="top-bar-text">+00 12345 67890</span>
						
						<i class="fa fa-skype fa-lg"></i>
						<span class="top-bar-text-2">gj-designs</span>
					</div>
					
					<div class="col-md-6">
						<ul class="top-socials">
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							<li><a href="#"><i class="fa fa-youtube"></i></a></li>
							<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
							<li><a href="#"><i class="fa fa-reddit"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		<!--End Home-->
		
		
		<nav class="navbar navbar-default" >
		  <div class="container container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			  <a class="navbar-brand" href="#"><img src="images/logo.png" alt="" /> </a>
			</div>

			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			  <ul class="nav navbar-nav navbar-right">
							<li>
								<a href="index.php">Home</a>
								<ul class="for-mob-menu">
									<li><a href="index.php">Home</a></li>
								</ul>
							</li>
							  
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle active" data-toggle="dropdown">Services <span class="caret"></span></a>
							  <ul class="dropdown-menu" role="menu">
								<li><a href="services.php">Services Version 1</a></li>
								<li><a href="services-2.php">Services Version 2</a></li>
							  </ul>
							  
							  <ul class="for-mob-menu">
								<li><a href="services.php">Services Version 1</a></li>
								<li><a href="services-2.php" class="active">Services Version 2</a></li>
							  </ul>
							</li>
							
							<li>
								<a href="about.php" >About Us</a>
								<ul class="for-mob-menu">
									<li><a href="about.php">About Us</a></li>
								</ul>
							</li>
							
							
							<li>
								<a href="portfolio.php" >Portfolio</a>
								<ul class="for-mob-menu">
									<li><a href="portfolio.php">Portfolio</a></li>
								</ul>
							</li>
							
							<li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Blog <span class="caret"></span></a>
							  <ul class="dropdown-menu" role="menu">
								<li><a href="blog.php">Blog</a></li>
								<li><a href="blog-post-1.php">Blog Single Post</a></li>
							  </ul>
							  
							  <ul class="for-mob-menu">
								<li><a href="blog.php">Blog</a></li>
								<li><a href="blog-post-1.php">Blog Single Post</a></li>
							  </ul>
							</li>
							
							<li>
								<a href="contact.php" >Contact</a>
								<ul class="for-mob-menu">
									<li><a href="contact.php">Contact</a></li>
								</ul>
							</li>
							
				</ul>
											
				<div class="sr">
					<input id="search" name="search" type="text" placeholder="What're you looking for ?">
					<input id="search_submit" value="Rechercher" type="submit">
				</div>
 
			</div><!-- /.navbar-collapse -->
			
			
		  </div><!-- /.container-fluid -->
		</nav>
		
		<div class="container header2-main">
			<div class="col-md-12">
				<h2>SERVICES</h2>
				<p>SEE WHAT SERVICES WE PROVIDE</p>
			</div>
		</div>
		
		</div>
		
		</header>
		<!-- End Header Section -->
		
		<!-- Start Services Main Section -->
		<div class="services2">
			<div class="container">
				<div class="col-md-12 ipad-img">
					<img src="images/ipad.png" alt="" />
				</div>
				
				<div class="col-md-6 s-box">
					<div class="tc-left">
						<div class="circle"><i class="fa fa-pencil"></i></div>
					</div>
						
					<div class="tc-right">
						<h3>Web Design</h3>
						<p>Anim pariatur cliche reprehenderit, enim eiusmod <br>high life accusamus terry richardson ad squid.</p>
					</div>	
				</div>
				
				<div class="col-md-6 s-box-2">
					<div class="pull-right">
						
						
						<div class="tc-right">
							<div class="circle"><i class="fa fa-bar-chart-o"></i></div>
						</div>
						
						<div class="tc-left">
							<h3>Marketing</h3>
							<p>Anim pariatur cliche reprehenderit, enim eiusmod <br>high life accusamus terry richardson ad squid.</p>
						</div>
					</div>
				</div>
				
				<div class="col-md-6 s-box">
					<div class="tc-left">
						<div class="circle"><i class="fa fa-paint-brush"></i></div>
					</div>
						
					<div class="tc-right">
						<h3>Logo Design</h3>
						<p>Anim pariatur cliche reprehenderit, enim eiusmod <br>high life accusamus terry richardson ad squid.</p>
					</div>	
				</div>
				
				<div class="col-md-6 s-box-2">
					<div class="pull-right">
						<div class="tc-right">
							<div class="circle"><i class="fa fa-codepen"></i></div>
						</div>	
						
						<div class="tc-left">
							<h3>Development</h3>
							<p>Anim pariatur cliche reprehenderit, enim eiusmod <br>high life accusamus terry richardson ad squid.</p>
						</div>
						
						
					</div>
				</div>
				
			</div>
		</div>
		<!-- End About Main Section -->
		
		<div class="whyuni">
			<div class="container">
				<div class="col-md-6 left">
					<h2>WHY UNIVERSAL</h2>
					<img src="images/ipad2.png" class="img-responsive" alt="" />
				</div>
			
				<div class="col-md-6 right">
					
					
					<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					  <div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingOne">
						  <h4 class="panel-title">
							<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
							  OUR SOLUTION
							</a>
						  </h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
						  <div class="panel-body">
							<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single origin coffee nulla assumenda shoreditch et.</p>
						  </div>
						</div>
					  </div>
					  <div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingTwo">
						  <h4 class="panel-title">
							<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
							  OUR MISSION
							</a>
						  </h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
						  <div class="panel-body">
							<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single origin coffee nulla assumenda shoreditch et.</p>
						  </div>
						</div>
					  </div>
					  <div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingThree">
						  <h4 class="panel-title">
							<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
							  OUR TECHNOLOGY
							</a>
						  </h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
						  <div class="panel-body">
							<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single origin coffee nulla assumenda shoreditch et.</p>
						  </div>
						</div>
					  </div>
					  
					   <div class="panel panel-default">
						<div class="panel-heading" role="tab" id="headingFour">
						  <h4 class="panel-title">
							<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
							  OUR FEATURES
							</a>
						  </h4>
						</div>
						<div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
						  <div class="panel-body">
							<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single origin coffee nulla assumenda shoreditch et.</p>
						  </div>
						</div>
					  </div>
					</div>
				</div>
				
				
				
			</div>
		</div>
		
		<div class="support">
			<div class="container">
				<div class="col-md-12 s-heading">
					
				</div>
				
				<div class="col-md-7">
					<img src="images/team3.png" alt="" />
				</div>
				
				<div class="col-md-5 right">
					<h2>AMAZING SUPPORT</h2>
					<h3>IT'S A 24/7 SUPPORT</h3>
					<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid.</p>
					<ul class="s-list">
						<li><i class="fa fa-check"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
						<li><i class="fa fa-check"></i> Nam consectetur justo nec nibh viverra faucibus.</li>
						<li><i class="fa fa-check"></i> Nulla consequat ex ut dignissim rhoncus. </li>
						<li><i class="fa fa-check"></i> Phasellus porttitor id diam eget ornare </li>
						<li><i class="fa fa-check"></i>  Aliquam nec diam tincidunt tellus dictum consequat.  </li>
					</ul>
				</div>
			</div>
		</div>
		
		
	
		
		<!-- Start Partners Section -->
		<div class="partners">
			<div class="container">
				<div class="col-md-12">
					<div id="owl3" class="owl-carousel">
						<div class="item"><img class="lazyOwl" src="images/partners/1.png" alt="" /></div>
						<div class="item"><img class="lazyOwl" src="images/partners/2.png" alt="" /></div>
						<div class="item"><img class="lazyOwl" src="images/partners/3.png" alt="" /></div>
						<div class="item"><img class="lazyOwl" src="images/partners/4.png" alt="" /></div>
						<div class="item"><img class="lazyOwl" src="images/partners/1.png" alt="" /></div>
						<div class="item"><img class="lazyOwl" src="images/partners/2.png" alt="" /></div>
						<div class="item"><img class="lazyOwl" src="images/partners/3.png" alt="" /></div>
						<div class="item"><img class="lazyOwl" src="images/partners/4.png" alt="" /></div>
					</div>
				</div>
			</div>
		</div>	
		<!-- End Partners Section -->
		
		<!-- Start Footer Section -->
		<footer>
			<div class="container">
				<div class="col-md-4 f-about">
					<h3>ABOUT UNIVERSAL</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce scelerisque nibh et neque faucibus suscipit. Sed auctor ipsum ut tellus faucibus tincidunt. Curabitur non quam facilisis, oncu ligula ac, pellen au ipsum. Fusce scelerisque nibh et nequeas faucibus suscipit. Sed auctor ipsum ut tell faucibus tincidunt. Fusce scelerisque nibh et neque faucibus suscipit.</p>
					<a href="index.php"><img src="images/logo.png" class="f-logo" alt="" /></a>
				</div>
				
				<div class="col-md-4 f-news">
					<h3>LATEST NEWS</h3>
					<div class="news-box">
						<div class="news-box-col">
							<div class="circle">1</div>
						</div>
						
						<div class="news-box-info">
							<h4>THIS IS LATEST NEWS HEADING.</h4>
							<a href="#" class="f-more-btn">READ MORE >></a>
						</div>
					</div>
					
					<div class="news-box">
						<div class="news-box-col">
							<div class="circle">2</div>
						</div>
						
						<div class="news-box-info">
							<h4>THIS IS LATEST NEWS HEADING.</h4>
							<a href="#" class="f-more-btn">READ MORE >></a>
						</div>
					</div>
					
				</div>
				
				<div class="col-md-4 f-info">
					<h3>CONTACT INFO</h3>
					<img src="images/footer-map.png" alt="" />
					<address>
						<strong>Address :</strong> 123, Colorful City, Dreamland, Stra Galaxy<br>
						<strong>Phone :</strong> +91 9501462604<br>
						<strong>Mail :</strong> support@gj-designs.in<br>
					</address>
				</div>
			</div>
		</footer>
		<!-- End Footer Section -->
		
		<!-- Start Under Footer Section -->
		<div class="under-footer">
			<div class="container">
				<div class="col-md-12">
					<div class="left">© 2015 All Rights Reserved. <abbr title="Universal">Universal</abbr></div>
					<div class="right pull-right">
						<ul class="f-socials">
							<li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter-square"></i></a></li>
							<li><a href="#"><i class="fa fa-skype"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus-square"></i></a></li>
							<li><a href="#"><i class="fa fa-youtube-square"></i></a></li>
							<li><a href="#"><i class="fa fa-rss-square"></i></a></li>
							<li><a href="#"><i class="fa fa-pinterest-square"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- End Under Footer Section -->
		
		
	
	<!-- Jquery Libs -->
	<!-- Latest Version Of Jquery -->
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<!-- Bootstrap.js -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<!-- Sticky PLugin -->
	<script src="js/jquery.sticky.js"></script>
	<!-- Cube Portfolio -->
	<script type="text/javascript" src="js/jquery.cubeportfolio.min.js"></script>
	<script type="text/javascript" src="js/cbp-1.js"></script>
	<!-- Owl Carousel -->
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<!-- Wow Plugin -->
	<script type="text/javascript" src="js/wow.min.js"></script>
	<!--Easing animations Plugin -->
	<script type="text/javascript" src="js/easing.js"></script>
	<!--To-Top Button Plugin -->
    <script type="text/javascript" src="js/jquery.ui.totop.js"></script>
	<!-- SmoothScroll Plugin -->
	<script type="text/javascript" src="js/SmoothScroll.js"></script>
	<script type="text/javascript" src="js/modernizr-latest.js"></script>
	<script type="text/javascript" src="js/classie.js"></script>
	<script type="text/javascript" src="js/uisearch.js"></script>
	<script type="text/javascript" src="js/waypoints.min.js"></script>
	<script type="text/javascript" src="js/jquery.easypiechart.min.js"></script>
	<!-- Theme Custom -->
	<script type="text/javascript" src="js/preloaders.js"></script>
	<script type="text/javascript" src="js/custom.js"></script>
	
	<!-- End Jquery Libs -->
	
	<script>
		jQuery().UItoTop({ easingType: 'easeOutQuart' });
	</script>

	</body>
	
<!-- Mirrored from gj-designs.in/universal/services-2.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 15 Oct 2016 14:52:30 GMT -->
</html>
